
GLabel = 'Car Parking'
GProcess = 'com.olzhas.carparking.multyplayer'
GVersion = '4.8.20.4'

local v = gg.getTargetInfo()
if v.processName~=GProcess then
gg.alert("This Script is For:\n"..GLabel.."\n"..GProcess.."\n\nYou Selected:\n"..v.label.."\n"..v.processName)
os.exit()
return
end

if GVersion~=v.versionName then
gg.alert("This Script is for Game Version:\n"..GVersion.."\n\nYour Game Version is:\n"..v.versionName) 
gg.setVisible(false)
os.exit() 
return
end

function TesterLua() end
function setvalue(address,flags,value) TesterLua('Modify address value(Address, value type, value to be modified)')
local tt = {}
tt[1]= {}
tt[1].address = address
tt[1].flags = flags
tt[1].value = value
gg.setValues(tt)
end

gg.setVisible(false)
gg.toast("CLICK GG LOGO")
function HOME()
QR = gg.choice({
[[ RANK KING ]], -- 1
[[ YOUTUBER ]], -- 2
[[ TIKTOKER ]], -- 3
[[ DEVELOPER ]], -- 4
[[ IG BLOGGER ]], -- 5
[[ ❌ E X I T ❌ ]],
},nil,os.date[[
┏━━━━━━━✰✰✰━━━━━━━┓
👤Script by: CPM-GG-20
➣ ☀️Today: %m/%d/%y
➣ ⌚Time: %H:%M
┗━━━━━━━✰✰✰━━━━━━━┛
]])
if QR == nil then else
if QR == 1 then D1() end
if QR == 2 then D2() end
if QR == 3 then D3() end
if QR == 4 then D4() end
if QR == 5 then D5() end
if QR == 17 then EXIT()
end
end
TESTER = -1
end

function D1() -- rank king
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x2D0E2A0 setvalue(Tester+Lua,16,-2.74884198e11)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x2D0E2A4 setvalue(Tester+Lua,16,-6.13017998e13)
gg.toast("ON")
end

function D2() -- rank youtuber
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x2D0E2A0 setvalue(Tester+Lua,16,-2.74886296e11)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x2D0E2A4 setvalue(Tester+Lua,16,-6.13017998e13)
gg.toast("ON")
end

function D3() -- rank tiktoker
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x2D0E2A0 setvalue(Tester+Lua,16,-2.74887344e11)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x2D0E2A4 setvalue(Tester+Lua,16,-6.13017998e13)
gg.toast("ON")
end

function D4() -- rank developer
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x2D0E2A0 setvalue(Tester+Lua,16,-2.74885247e11)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x2D0E2A4 setvalue(Tester+Lua,16,-6.13017998e13)
gg.toast("ON")
end

function D5() -- ig blogger
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x2D0E2A0 setvalue(Tester+Lua,16,-2.74888393e11)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x2D0E2A4 setvalue(Tester+Lua,16,-6.13017998e13)
gg.toast("ON")
end

function EXIT()
gg.toast("EXIT ✔")
gg.clearResults()
gg.clearList()
os.exit()
end 

while true do
if gg.isVisible(true) then
TESTER = 1
gg.setVisible(false)
end
if TESTER == 1 then
HOME()
end
end

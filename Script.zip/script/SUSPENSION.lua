
GLabel = 'Car Parking'
GProcess = 'com.olzhas.carparking.multyplayer'
GVersion = '4.8.20.4'

local v = gg.getTargetInfo()
if v.processName~=GProcess then
gg.alert("This Script is For:\n"..GLabel.."\n"..GProcess.."\n\nYou Selected:\n"..v.label.."\n"..v.processName)
os.exit()
return
end

if GVersion~=v.versionName then
gg.alert("This Script is for Game Version:\n"..GVersion.."\n\nYour Game Version is:\n"..v.versionName) 
gg.setVisible(false)
os.exit() 
return
end

gg.setVisible(false)
gg.toast("CLICK GG LOGO")
function HOME()
QR = gg.choice({
[[ UFO 1 ]], -- 1
[[ UFO 2 ]], -- 2
[[ UFO 3 ]], -- 3
[[ ANGLE 90 ]], -- 4
[[ ANGLE 110 ]], -- 5
[[ ANGLE 105 ]], -- 6
[[ CUSTOM UFO ]], -- 7
[[ CUSTOM ANGLE ]], -- 8
[[ ❌ E X I T ❌ ]],
},nil,os.date[[
┏━━━━━━━✰✰✰━━━━━━━┓
👤Script by: CPM-GG-20
➣ ☀️Today: %m/%d/%y
➣ ⌚Time: %H:%M
┗━━━━━━━✰✰✰━━━━━━━┛
]])
if QR == nil then else
if QR == 1 then H1() end
if QR == 2 then H2() end
if QR == 3 then H3() end
if QR == 4 then H4() end
if QR == 5 then H5() end
if QR == 6 then H6() end
if QR == 7 then H7() end
if QR == 8 then H8() end
if QR == 9 then EXIT()
end
end
TESTER = -1
end

function H1()
gg.setVisible(false)
gg.alert ("MAX YOUR INCLINE THEN CLICK ON THE GG LOGO TO START")
gg.clearResults()
gg.clearList()
while true do
if gg.isVisible() then
break
else
gg.sleep(50)
end end gg.setVisible(false) gg.clearResults()
gg.clearResults()
gg.clearList()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber("-10",gg.TYPE_FLOAT)
gg.refineNumber("-10")
gg.getResults(100)
gg.editAll("-130",gg.TYPE_FLOAT)
gg.toast("ON")
gg.clearResults()
gg.clearList()
end

function H2()
gg.setVisible(false)
gg.alert ("MAX YOUR INCLINE THEN CLICK ON THE GG LOGO TO START")
gg.clearResults()
gg.clearList()
while true do
if gg.isVisible() then
break
else
gg.sleep(50)
end end gg.setVisible(false) gg.clearResults()
gg.clearResults()
gg.clearList()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber("-10",gg.TYPE_FLOAT)
gg.refineNumber("-10")
gg.getResults(100)
gg.editAll("-90",gg.TYPE_FLOAT)
gg.toast("ON")
gg.clearResults()
gg.clearList()
end

function H3()
gg.setVisible(false)
gg.alert ("MAX YOUR INCLINE THEN CLICK ON THE GG LOGO TO START")
gg.clearResults()
gg.clearList()
while true do
if gg.isVisible() then
break
else
gg.sleep(50)
end end gg.setVisible(false) gg.clearResults()
gg.clearResults()
gg.clearList()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber("-10",gg.TYPE_FLOAT)
gg.refineNumber("-10")
gg.getResults(100)
gg.editAll("-75",gg.TYPE_FLOAT)
gg.toast("ON")
gg.clearResults()
gg.clearList()
end

function H4()
gg.setVisible(false)
gg.alert ("MAX YOUR ANGLE THEN CLICK ON THE GG LOGO TO START")
gg.clearResults()
gg.clearList()
while true do
if gg.isVisible() then
break
else
gg.sleep(50)
end end gg.setVisible(false) gg.clearResults()
gg.clearResults()
gg.clearList()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber("60",gg.TYPE_FLOAT)
gg.setVisible(false)
gg.getResults(100)
gg.alert("MAKE YOUR STERING 30 FAST")
gg.sleep("5000")
gg.refineNumber("30")
gg.setVisible(false)
gg.getResults(3)
gg.editAll("90",gg.TYPE_FLOAT)
gg.toast("ON")
gg.clearResults()
gg.clearList()
end

function H5()
gg.setVisible(false)
gg.alert ("MAX YOUR ANGLE THEN CLICK ON THE GG LOGO TO START")
gg.clearResults()
gg.clearList()
while true do
if gg.isVisible() then
break
else
gg.sleep(50)
end end gg.setVisible(false) gg.clearResults()
gg.clearResults()
gg.clearList()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber("60",gg.TYPE_FLOAT)
gg.setVisible(false)
gg.getResults(100)
gg.alert("MAKE YOUR STERING 30 FAST")
gg.sleep("5000")
gg.refineNumber("30")
gg.setVisible(false)
gg.getResults(3)
gg.editAll("110",gg.TYPE_FLOAT)
gg.toast("ON")
gg.clearResults()
gg.clearList()
end

function H6()
gg.setVisible(false)
gg.alert ("MAX YOUR ANGLE THEN CLICK ON THE GG LOGO TO START")
gg.clearResults()
gg.clearList()
while true do
if gg.isVisible() then
break
else
gg.sleep(50)
end end gg.setVisible(false) gg.clearResults()
gg.clearResults()
gg.clearList()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber("60",gg.TYPE_FLOAT)
gg.setVisible(false)
gg.getResults(100)
gg.alert("MAKE YOUR STERING 30 FAST")
gg.sleep("5000")
gg.refineNumber("30")
gg.setVisible(false)
gg.getResults(3)
gg.editAll("105",gg.TYPE_FLOAT)
gg.toast("ON")
gg.clearResults()
gg.clearList()
end

function H7() -- custom ufo
gg.setVisible(false)
d=gg.prompt({"EDIT UFO ","BACK"},nil,{"number","checkbox"}) if not d then return end if d == nil then Menu() end gg.clearResults() gg.setVisible(false) if d[2] then return gg.setVisible(true) end 
gg.alert ("MAX YOUR INCLINE THEN CLICK IN THE GG LOGO TO START")
gg.clearResults()
gg.clearList()
while true do
if gg.isVisible() then
break
else
gg.sleep(50)
end end gg.setVisible(false) gg.clearResults()
gg.clearResults()
gg.clearList()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber("-10",gg.TYPE_FLOAT)
gg.refineNumber("-10")
gg.getResults(100)
gg.editAll(d[ 1 ],gg.TYPE_FLOAT)
gg.toast("ON")
gg.clearResults()
gg.clearList()
end

function H8() -- custom angle
gg.setVisible(false)
d=gg.prompt({"EDIT ANGLE","BACK"},nil,{"number","checkbox"}) if not d then return end if d == nil then Menu() end gg.clearResults() gg.setVisible(false) if d[2] then return gg.setVisible(true) end 
gg.setVisible(false)
gg.alert ("MAX YOUR ANGLE THEN CLICK ON THE GG LOGO TO START")
gg.clearResults()
gg.clearList()
while true do
if gg.isVisible() then
break
else
gg.sleep(50)
end end gg.setVisible(false) gg.clearResults()
gg.clearResults()
gg.clearList()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber("60",gg.TYPE_FLOAT)
gg.setVisible(false)
gg.getResults(100)
gg.alert("MAKE YOUR STERING 30 FAST")
gg.sleep("5000")
gg.refineNumber("30")
gg.setVisible(false)
gg.getResults(3)
gg.editAll(d[ 1 ],gg.TYPE_FLOAT)
gg.toast("ON")
gg.clearResults()
gg.clearList()
end

function EXIT()
gg.toast("EXIT ✔")
gg.clearResults()
gg.clearList()
os.exit()
end 

while true do
if gg.isVisible(true) then
TESTER = 1
gg.setVisible(false)
end
if TESTER == 1 then
HOME()
end
end


GLabel = 'Car Parking'
GProcess = 'com.olzhas.carparking.multyplayer'
GVersion = '4.8.20.4'

local v = gg.getTargetInfo()
if v.processName~=GProcess then
gg.alert("This Script is For:\n"..GLabel.."\n"..GProcess.."\n\nYou Selected:\n"..v.label.."\n"..v.processName)
os.exit()
return
end

if GVersion~=v.versionName then
gg.alert("This Script is for Game Version:\n"..GVersion.."\n\nYour Game Version is:\n"..v.versionName) 
gg.setVisible(false)
os.exit() 
return
end

function TesterLua() end
function setvalue(address,flags,value) TesterLua('Modify address value(Address, value type, value to be modified)')
local tt = {}
tt[1]= {}
tt[1].address = address
tt[1].flags = flags
tt[1].value = value
gg.setValues(tt)
end

on = "🔴⃢  "
off = "    ⃢🟢"

-- tune up
hp320 = on
hp90 = on
hp1695 = on
hp1466 = on
hp2000 = on
hp300 = on
hp98 = on
hp925 = on
customhp = on

-- shift time
shift00001 = on
shift1e30 = on
shift1e29 = on
customshift = on

gg.setVisible(false)
gg.toast("CLICK GG LOGO")
function HOME()
QR = gg.choice({
[[ 320HP ]]..hp320, -- 1
[[ 90HP ]]..hp90, -- 2
[[ 1695HP ]]..hp1695, -- 3
[[ 1466HP ]]..hp1466, -- 4
[[ 2000HP ]]..hp2000, -- 5
[[ 300HP ]]..hp300, -- 6
[[ 98HP ]]..hp98, -- 7
[[ 925HP ]]..hp925, -- 8
[[ CUSTOM HP ]]..customhp, -- 9
[[ SHIFT TIME 0.0001 ]]..shift00001, -- 10
[[ SHIFT TIME 1E-30 ]]..shift1e30, -- 11
[[ SHIFT TIME 1E-29 ]]..shift1e29, -- 12
[[ CUSTOM SHIFT TIME ]]..customshift, -- 13
[[ CUSTOM WITHOUT ENGINE ]], -- 14
[[ ❌ E X I T ❌ ]]
},nil,os.date[[
┏━━━━━━━✰✰✰━━━━━━━┓
👤Script by: CPM-GG-20
➣ ☀️Today: %m/%d/%y
➣ ⌚Time: %H:%M
┗━━━━━━━✰✰✰━━━━━━━┛
]])
if QR == nil then else
if QR == 1 then if hp320 == on then  C2 (on) hp320 = off else C3 (off) hp320 = on end end
if QR == 2 then if hp90 == on then  C4 (on) hp90 = off else C5 (off) hp90 = on end end
if QR == 3 then if hp1695 == on then C6 (on) hp1695 = off else C7 (off) hp1695 = on end end
if QR == 4 then if hp1466 == on then C8 (on) hp1466 = off else C9 (off) hp1466 = on end end
if QR == 5 then if hp2000 == on then  C10 (on) hp2000 = off else C11 (off) hp2000 = on end end
if QR == 6 then if hp300 == on then  C12 (on) hp300 = off else C13 (off) hp300 = on end end
if QR == 7 then if hp98 == on then  C14 (on) hp98 = off else C15 (off) hp98 = on end end
if QR == 8 then if hp925 == on then  C16 (on) hp925 = off else C17 (off) hp925 = on end end
if QR == 9 then if customhp == on then  C18 (on) customhp = off else C19 (off) customhp = on end end
if QR == 10 then if shift00001 == on then  C20 (on) shift00001 = off else C21 (off) shift00001 = on end end
if QR == 11 then if shift1e30 == on then  C22 (on) shift1e30 = off else C23 (off) shift1e30 = on end end
if QR == 12  then if shift1e29 == on then  C24 (on) shift1e29 = off else C25 (off) shift1e29 = on end end
if QR == 13 then if customshift == on then C26 (on) customshift = off else C27 (off) customshift = on end end
if QR == 14 then C28() end
if QR == 15 then EXIT()
end
end
TESTER = -1
end

function C2() -- 320hp on
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5FCE6D4 setvalue(Tester+Lua,16,320)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5FCE6D8 setvalue(Tester+Lua,16,2299)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x62199E8 setvalue(Tester+Lua,16,8000)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x622AC04 setvalue(Tester+Lua,16,5000)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5BFC5A0 setvalue(Tester+Lua,16,320)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5D29074 setvalue(Tester+Lua,16,2299)
gg.alert ('BUY ENGINE V6 3.5')
gg.toast("ON")
end

function C3() -- 320hp off
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5FCE6D4 setvalue(Tester+Lua,16,280)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5FCE6D8 setvalue(Tester+Lua,16,350)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x62199E8 setvalue(Tester+Lua,16,6300)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x622AC04 setvalue(Tester+Lua,16,4700)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5BFC5A0 setvalue(Tester+Lua,16,2000)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5D29074 setvalue(Tester+Lua,16,3000)
gg.toast("OFF")
end

function C4() -- 90hp on
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5FCE6D4 setvalue(Tester+Lua,16,90)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5FCE6D8 setvalue(Tester+Lua,16,2300)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x62199E8 setvalue(Tester+Lua,16,8000)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x622AC04 setvalue(Tester+Lua,16,7899)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5BFC5A0 setvalue(Tester+Lua,16,90)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5D29074 setvalue(Tester+Lua,16,2300)
gg.alert ('BUY ENGINE V6 3.5')
gg.toast("ON")
end

function C5() -- 90hp off
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5FCE6D4 setvalue(Tester+Lua,16,280)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5FCE6D8 setvalue(Tester+Lua,16,350)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x62199E8 setvalue(Tester+Lua,16,6300)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x622AC04 setvalue(Tester+Lua,16,4700)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5BFC5A0 setvalue(Tester+Lua,16,2000)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5D29074 setvalue(Tester+Lua,16,3000)
gg.toast("OFF")
end

function C6() -- 1695hp on
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5FCE6D4 setvalue(Tester+Lua,16,1695)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5FCE6D8 setvalue(Tester+Lua,16,2254)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x62199E8 setvalue(Tester+Lua,16,7000)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x622AC04 setvalue(Tester+Lua,16,3500)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5BFC5A0 setvalue(Tester+Lua,16,1695)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5D29074 setvalue(Tester+Lua,16,2254)
gg.alert ('BUY ENGINE V6 3.5')
gg.toast("ON")
end

function C7() -- 1695hp off
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5FCE6D4 setvalue(Tester+Lua,16,280)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5FCE6D8 setvalue(Tester+Lua,16,350)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x62199E8 setvalue(Tester+Lua,16,6300)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x622AC04 setvalue(Tester+Lua,16,4700)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5BFC5A0 setvalue(Tester+Lua,16,2000)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5D29074 setvalue(Tester+Lua,16,3000)
gg.toast("OFF")
end

function C8() -- 1466hp on
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5FCE6D4 setvalue(Tester+Lua,16,1466)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5FCE6D8 setvalue(Tester+Lua,16,1690)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x62199E8 setvalue(Tester+Lua,16,5948)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x622AC04 setvalue(Tester+Lua,16,5937)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5BFC5A0 setvalue(Tester+Lua,16,1466)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5D29074 setvalue(Tester+Lua,16,1690)
gg.alert ('BUY ENGINE V6 3.5')
gg.toast("ON")
end

function C9() -- 1466hp off
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5FCE6D4 setvalue(Tester+Lua,16,280)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5FCE6D8 setvalue(Tester+Lua,16,350)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x62199E8 setvalue(Tester+Lua,16,6300)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x622AC04 setvalue(Tester+Lua,16,4700)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5BFC5A0 setvalue(Tester+Lua,16,2000)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5D29074 setvalue(Tester+Lua,16,3000)
gg.toast("OFF")
end

function C10() -- 2000hp on
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5FCE6D4 setvalue(Tester+Lua,16,2000)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5FCE6D8 setvalue(Tester+Lua,16,3000)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x62199E8 setvalue(Tester+Lua,16,8000)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x622AC04 setvalue(Tester+Lua,16,7899)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5BFC5A0 setvalue(Tester+Lua,16,2000)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5D29074 setvalue(Tester+Lua,16,3000)
gg.alert ('BUY ENGINE V6 3.5')
gg.toast("ON")
end

function C11() -- 2000hp off
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5FCE6D4 setvalue(Tester+Lua,16,280)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5FCE6D8 setvalue(Tester+Lua,16,350)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x62199E8 setvalue(Tester+Lua,16,6300)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x622AC04 setvalue(Tester+Lua,16,4700)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5BFC5A0 setvalue(Tester+Lua,16,2000)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5D29074 setvalue(Tester+Lua,16,3000)
gg.toast("OFF")
end

function C12() -- 300hp on
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5FCE6D4 setvalue(Tester+Lua,16,300)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5FCE6D8 setvalue(Tester+Lua,16,2300)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x62199E8 setvalue(Tester+Lua,16,8000)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x622AC04 setvalue(Tester+Lua,16,7899)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5BFC5A0 setvalue(Tester+Lua,16,300)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5D29074 setvalue(Tester+Lua,16,2300)
gg.alert ('BUY ENGINE V6 3.5')
gg.toast("ON")
end

function C13() -- 300hp off
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5FCE6D4 setvalue(Tester+Lua,16,280)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5FCE6D8 setvalue(Tester+Lua,16,350)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x62199E8 setvalue(Tester+Lua,16,6300)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x622AC04 setvalue(Tester+Lua,16,4700)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5BFC5A0 setvalue(Tester+Lua,16,2000)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5D29074 setvalue(Tester+Lua,16,3000)
gg.toast("OFF")
end

function C14() -- 98hp on
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5FCE6D4 setvalue(Tester+Lua,16,98)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5FCE6D8 setvalue(Tester+Lua,16,2300)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x62199E8 setvalue(Tester+Lua,16,100000)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x622AC04 setvalue(Tester+Lua,16,7899)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5BFC5A0 setvalue(Tester+Lua,16,98)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5D29074 setvalue(Tester+Lua,16,2300)
gg.alert ('BUY ENGINE V6 3.5')
gg.toast("ON")
end

function C15() -- 98hp off
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5FCE6D4 setvalue(Tester+Lua,16,280)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5FCE6D8 setvalue(Tester+Lua,16,350)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x62199E8 setvalue(Tester+Lua,16,6300)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x622AC04 setvalue(Tester+Lua,16,4700)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5BFC5A0 setvalue(Tester+Lua,16,2000)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5D29074 setvalue(Tester+Lua,16,3000)
gg.toast("OFF")
end

function C16() -- 925hp on
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5FCE6D4 setvalue(Tester+Lua,16,925)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5FCE6D8 setvalue(Tester+Lua,16,1804)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x62199E8 setvalue(Tester+Lua,16,7000)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x622AC04 setvalue(Tester+Lua,16,3500)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5BFC5A0 setvalue(Tester+Lua,16,925)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5D29074 setvalue(Tester+Lua,16,1804)
gg.alert ('BUY ENGINE V6 3.5')
gg.toast("ON")
end

function C17() -- 925hp off
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5FCE6D4 setvalue(Tester+Lua,16,280)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5FCE6D8 setvalue(Tester+Lua,16,350)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x62199E8 setvalue(Tester+Lua,16,6300)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x622AC04 setvalue(Tester+Lua,16,4700)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5BFC5A0 setvalue(Tester+Lua,16,2000)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5D29074 setvalue(Tester+Lua,16,3000)
gg.toast("OFF")
end

function C18() -- custom hp on
gg.setVisible(false)
gg.clearResults()
gg.clearList()
d = gg.prompt({"EDIT HP","EDIT NM","EDIT INNER HP","EDIT INNER NM","BACK"},nil,{"number","number","number","number","checkbox"}) if not d then return end if d == nil then Menu() end gg.clearResults() gg.setVisible(false) if d[5] then return gg.setVisible(true) end 
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5FCE6D4 setvalue(Tester+Lua,16,d[1])
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5FCE6D8 setvalue(Tester+Lua,16,d[2])
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x62199E8 setvalue(Tester+Lua,16,d[3])
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x622AC04 setvalue(Tester+Lua,16,d[4])
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5BFC5A0 setvalue(Tester+Lua,16,d[1])
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5D29074 setvalue(Tester+Lua,16,d[2])
gg.alert ('BUY ENGINE V6 3.5')
gg.toast("ON")
end

function C19() -- custom hp off
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5FCE6D4 setvalue(Tester+Lua,16,280)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5FCE6D8 setvalue(Tester+Lua,16,350)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x62199E8 setvalue(Tester+Lua,16,6300)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x622AC04 setvalue(Tester+Lua,16,4700)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5BFC5A0 setvalue(Tester+Lua,16,2000)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5D29074 setvalue(Tester+Lua,16,3000)
gg.toast("OFF")
end

function C20() -- shift time 0.0001 on
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5BFC3AC setvalue(Tester+Lua,16,0.0001)
gg.alert ('BUY FAST GEARBOX')
gg.toast("ON")
end

function C21() -- shift time 0.0001 off
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5BFC3AC setvalue(Tester+Lua,16,0.1)
gg.toast("OFF")
end

function C22() -- shift time 1e-30 on
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5BFC3AC setvalue(Tester+Lua,16,1e-30)
gg.alert ('BUY FAST GEARBOX')
gg.toast("ON")
end

function C23() -- shift time 1e-30 off
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5BFC3AC setvalue(Tester+Lua,16,0.1)
gg.toast("OFF")
end

function C24() -- shift time 1e-29 on
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5BFC3AC setvalue(Tester+Lua,16,1e-29)
gg.alert ('BUY FAST GEARBOX')
gg.toast("ON")
end

function C25() -- shift time 1e-29 off
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5BFC3AC setvalue(Tester+Lua,16,0.1)
gg.toast("OFF")
end

function C26() -- custom shift time on
gg.setVisible(false)
gg.clearResults()
gg.clearList()
d=gg.prompt({"EDIT SHIFT TIME","BACK"},nil,{"number","checkbox"}) if not d then return end if d == nil then Menu() end gg.clearResults() gg.setVisible(false) if d[2] then return gg.setVisible(true) end 
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5BFC3AC setvalue(Tester+Lua,16,d[1])
gg.alert ('BUY FAST GEARBOX')
gg.toast("ON")
end

function C27() -- custom shift time off
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5BFC3AC setvalue(Tester+Lua,16,0.1)
gg.toast("OFF")
end

function C28() -- custom hp without engine
d = gg.prompt({"INPUT HP","EDIT HP","INPUT NM","INPUT NM","INPUT INNER HP","EDIT INNER HP","INPUT INNER NM","EDIT INNER NM","BACK"},nil,{"number","number","number","number","number","number","number","number","checkbox"})
if not d then
return
end
if d == nil then
Menu()
end
gg.clearResults()
gg.setVisible(false)
if d[9] then
return
gg.setVisible(true)
end

gg.setVisible(false)
gg.clearResults()
gg.clearList()
gg.setRanges(16384)
gg.searchNumber(d[1], 16)
gg.getResults(9999)
gg.editAll(d[2], 16)
gg.clearResults()
gg.searchNumber(d[3], 16)
gg.getResults(9999)
gg.editAll(d[4], 16)
gg.clearResults()
gg.searchNumber(d[5], 16)
gg.getResults(9999)
gg.editAll(d[6], 16)
gg.clearResults()
gg.searchNumber(d[7], 16)
gg.getResults(9999)
gg.editAll(d[8], 16)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5BFC5A0 setvalue(Tester+Lua,16,d[2])
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5D29074 setvalue(Tester+Lua,16,d[4])
gg.clearResults()
gg.clearList()
gg.alert("CLICK ON (RESET)")
gg.toast("ON")
end

function EXIT()
gg.toast("EXIT ✔")
gg.clearResults()
gg.clearList()
os.exit()
end 

while true do
if gg.isVisible(true) then
TESTER = 1
gg.setVisible(false)
end
if TESTER == 1 then
HOME()
end
end

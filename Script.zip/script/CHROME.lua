
GLabel = 'Car Parking'
GProcess = 'com.olzhas.carparking.multyplayer'
GVersion = '4.8.20.4'

local v = gg.getTargetInfo()
if v.processName~=GProcess then
gg.alert("This Script is For:\n"..GLabel.."\n"..GProcess.."\n\nYou Selected:\n"..v.label.."\n"..v.processName)
os.exit()
return
end

if GVersion~=v.versionName then
gg.alert("This Script is for Game Version:\n"..GVersion.."\n\nYour Game Version is:\n"..v.versionName) 
gg.setVisible(false)
os.exit() 
return
end

gg.setVisible(false)
gg.toast("CLICK GG LOGO")
function HOME()
QR = gg.choice({
[[ CHROME 1 ]], -- 1
[[ CHROME 2 ]], -- 2
[[ CHROME 3 ]], -- 3
[[ CUSTOM CHROME ]], -- 4
[[ ❌ E X I T ❌ ]],
},nil,os.date[[
┏━━━━━━━✰✰✰━━━━━━━┓
👤Script by: CPM-GG-20
➣ ☀️Today: %m/%d/%y
➣ ⌚Time: %H:%M
┗━━━━━━━✰✰✰━━━━━━━┛
]])
if QR == nil then else
if QR == 1 then H1() end
if QR == 2 then H2() end
if QR == 3 then H3() end
if QR == 4 then H4() end
if QR == 5 then H5() end
if QR == 6 then H6() end
if QR == 7 then H7() end
if QR == 8 then H8() end
if QR == 9 then EXIT()
end
end
TESTER = -1
end

function I1() -- chrome -6
gg.setVisible(false)
gg.alert("SEARCH SPECULAR AND SLIDE UP THEN CLICK ON THE GG LOGO TO START")
gg.clearResults()
gg.clearList()
while true do
if gg.isVisible() then
break
else
gg.sleep(50)
end end gg.setVisible(false) gg.clearResults()
gg.clearResults()
gg.clearList()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber("1", gg.TYPE_FLOAT)
gg.setVisible(false)
revert = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
gg.alert("SLIDE DOWN")
gg.sleep(3500)
gg.refineNumber("0", gg.TYPE_FLOAT)
gg.setVisible(false)
revert = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
gg.alert("SLIDE UP")
gg.sleep(3500)
gg.refineNumber("1", gg.TYPE_FLOAT)
gg.setVisible(false)
revert = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
gg.alert("SLIDE DOWN")
gg.sleep(3500)
gg.refineNumber("0", gg.TYPE_FLOAT)
gg.setVisible(false)
revert = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
gg.alert("SLIDE UP")
gg.sleep(3500)
gg.refineNumber("1", gg.TYPE_FLOAT)
gg.setVisible(false)
revert = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
gg.alert("SLIDE DOWN")
gg.sleep(3500)
gg.refineNumber("0", gg.TYPE_FLOAT)
gg.setVisible(false)
revert = gg.getResults(72, nil, nil, nil, nil, nil, nil, nil, nil)
gg.editAll("-6", gg.TYPE_FLOAT)
gg.toast("ON")
gg.clearResults()
gg.clearList()
end

function I2() -- chrome 4
gg.setVisible(false)
gg.alert("SEARCH SPECULAR AND SLIDE UP THEN CLICK ON THE GG LOGO TO START")
gg.clearResults()
gg.clearList()
while true do
if gg.isVisible() then
break
else
gg.sleep(50)
end end gg.setVisible(false) gg.clearResults()
gg.clearResults()
gg.clearList()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber("1", gg.TYPE_FLOAT)
gg.setVisible(false)
revert = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
gg.alert("SLIDE DOWN")
gg.sleep(3500)
gg.refineNumber("0", gg.TYPE_FLOAT)
gg.setVisible(false)
revert = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
gg.alert("SLIDE UP")
gg.sleep(3500)
gg.refineNumber("1", gg.TYPE_FLOAT)
gg.setVisible(false)
revert = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
gg.alert("SLIDE DOWN")
gg.sleep(3500)
gg.refineNumber("0", gg.TYPE_FLOAT)
gg.setVisible(false)
revert = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
gg.alert("SLIDE UP")
gg.sleep(3500)
gg.refineNumber("1", gg.TYPE_FLOAT)
gg.setVisible(false)
revert = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
gg.alert("SLIDE DOWN")
gg.sleep(3500)
gg.refineNumber("0", gg.TYPE_FLOAT)
gg.setVisible(false)
revert = gg.getResults(72, nil, nil, nil, nil, nil, nil, nil, nil)
gg.editAll("4", gg.TYPE_FLOAT)
gg.toast("ON")
gg.clearResults()
gg.clearList()
end

function I3() -- chrome 2
gg.setVisible(false)
gg.alert("SEARCH SPECULAR AND SLIDE UP THEN CLICK ON THE GG LOGO TO START")
gg.clearResults()
gg.clearList()
while true do
if gg.isVisible() then
break
else
gg.sleep(50)
end end gg.setVisible(false) gg.clearResults()
gg.clearResults()
gg.clearList()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber("1", gg.TYPE_FLOAT)
gg.setVisible(false)
revert = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
gg.alert("SLIDE DOWN")
gg.sleep(3500)
gg.refineNumber("0", gg.TYPE_FLOAT)
gg.setVisible(false)
revert = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
gg.alert("SLIDE UP")
gg.sleep(3500)
gg.refineNumber("1", gg.TYPE_FLOAT)
gg.setVisible(false)
revert = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
gg.alert("SLIDE DOWN")
gg.sleep(3500)
gg.refineNumber("0", gg.TYPE_FLOAT)
gg.setVisible(false)
revert = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
gg.alert("SLIDE UP")
gg.sleep(3500)
gg.refineNumber("1", gg.TYPE_FLOAT)
gg.setVisible(false)
revert = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
gg.alert("SLIDE DOWN")
gg.sleep(3500)
gg.refineNumber("0", gg.TYPE_FLOAT)
gg.setVisible(false)
revert = gg.getResults(72, nil, nil, nil, nil, nil, nil, nil, nil)
gg.editAll("2", gg.TYPE_FLOAT)
gg.toast("ON")
gg.clearResults()
gg.clearList()
end

function I4() -- custom chrome
gg.setVisible(false)
d = gg.prompt({"EDIT CHROME","BACK"},nil,{"number","checkbox"}) if not d then return end if d == nil then Menu() end gg.clearResults() gg.setVisible(false) if d[2] then return gg.setVisible(true) end
gg.setVisible(false)
gg.alert("SEARCH SPECULAR AND SLIDE UP THEN CLICK ON THE GG LOGO TO START")
gg.clearResults()
gg.clearList()
while true do
if gg.isVisible() then
break
else
gg.sleep(50)
end end gg.setVisible(false) gg.clearResults()
gg.clearResults()
gg.clearList()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber("1", gg.TYPE_FLOAT)
gg.setVisible(false)
revert = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
gg.alert("SLIDE DOWN")
gg.sleep(5000)
gg.refineNumber("0", gg.TYPE_FLOAT)
gg.setVisible(false)
revert = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
gg.alert("SLIDE UP")
gg.sleep(5000)
gg.refineNumber("1", gg.TYPE_FLOAT)
gg.setVisible(false)
revert = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
gg.alert("SLIDE DOWN")
gg.sleep(5000)
gg.refineNumber("0", gg.TYPE_FLOAT)
gg.setVisible(false)
revert = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
gg.alert("SLIDE UP")
gg.sleep(5000)
gg.refineNumber("1", gg.TYPE_FLOAT)
gg.setVisible(false)
revert = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
gg.alert("SLIDE DOWN")
gg.sleep(5000)
gg.refineNumber("0", gg.TYPE_FLOAT)
gg.setVisible(false)
revert = gg.getResults(72, nil, nil, nil, nil, nil, nil, nil, nil)
gg.editAll(d[1],gg.TYPE_FLOAT) 
gg.toast("ON")
gg.clearResults()
gg.clearList()
end

function EXIT()
gg.toast("EXIT ✔")
gg.clearResults()
gg.clearList()
os.exit()
end 

while true do
if gg.isVisible(true) then
TESTER = 1
gg.setVisible(false)
end
if TESTER == 1 then
HOME()
end
end

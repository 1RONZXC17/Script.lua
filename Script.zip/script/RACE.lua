
GLabel = 'Car Parking'
GProcess = 'com.olzhas.carparking.multyplayer'
GVersion = '4.8.20.4'

local v = gg.getTargetInfo()
if v.processName~=GProcess then
gg.alert("This Script is For:\n"..GLabel.."\n"..GProcess.."\n\nYou Selected:\n"..v.label.."\n"..v.processName)
os.exit()
return
end

if GVersion~=v.versionName then
gg.alert("This Script is for Game Version:\n"..GVersion.."\n\nYour Game Version is:\n"..v.versionName) 
gg.setVisible(false)
os.exit() 
return
end

function search(class, offset, tryHard, bit32, valueType)
Get_user_input = {}
Get_user_input[1] = class
Get_user_input[2] = offset
Get_user_input[3] = tryHard
Get_user_input[4] = bit32
Get_user_type = valueType
start()
end

function loopCheck()
if userMode == 1 then
UI()
elseif error == 3 then
os.exit()
end
end

function found_(message)
if error == 1 then
found2(message)
elseif error == 2 then
found3(message)
elseif error == 3 then
found4(message)
else
found(message)
end
end

function found(message)
if count == 0 then
gg.clearResults()
gg.clearList()
first_error = message
error = 1
second_start()
end
end

function found2(message)
if count == 0 then
gg.clearResults()
gg.clearList()
second_error = message
error = 2
third_start()
end
end

function found3(message)
if count == 0 then
gg.clearResults()
gg.clearList()
third_error = message
error = 3
fourth_start()
end
end

function found4(message)
if count == 0 then
gg.clearResults()
gg.clearList()
gg.setVisible(true)
gg.alert("❌Value NOT FOUND❌")
loopCheck()
end
end

function user_input_taker()
::stort::
gg.clearResults()
if userMode == 1 then
if Get_user_input == nil then
default1 = "PlayerController"
default2 = "0x148"
default3 = false
default4 = false
else
default1 = Get_user_input[1]
default2 = Get_user_input[2]
default3 = Get_user_input[3]
default4 = Get_user_input[4]
end
Get_user_input = gg.prompt(
{"Class Name: ", "Offset: ","Try Harder -- (decreases accuracy)","Try For 32 bit"},
{default1,default2,default3,default4},
{"text","text","checkbox","checkbox"})
if Get_user_input ~= nil then
if (Get_user_input[1] == "") or (Get_user_input[2] == "") then
gg.alert("ℹ️ Don't Leave Input Blankℹ️")
goto stort
end
else
gg.alert("ℹ️ Error : Try again ℹ️")
goto stort
end
Get_user_type = gg.choice({"1. Byte / Boolean","2. Dword / 32 bit Int","3. Qword / 64 bit Int","4. Float","5. Double"})
if Get_user_type == 1 then
Get_user_type = gg.TYPE_BYTE
elseif Get_user_type == 2 then
Get_user_type = gg.TYPE_DWORD
elseif Get_user_type == 3 then
Get_user_type = gg.TYPE_QWORD
elseif Get_user_type == 4 then
Get_user_type = gg.TYPE_FLOAT
elseif Get_user_type == 5 then
Get_user_type = gg.TYPE_DOUBLE
end
if Get_user_type ~= gg.TYPE_BYTE then
if (Get_user_input[2] % 4) ~= 0 then
gg.alert("ℹ️Hex Offset Must Be An Multiple OF 4ℹ️")
goto stort
end
end
end
error = 0 
end

function O_initial_search()
gg.setVisible(false)
gg.toast("🟢First Try")
user_input = ":"..Get_user_input[1] 
if Get_user_input[3] then
offst = 25
else
offst = 0
end
end

function O_dinitial_search()
if error > 1 then
gg.setRanges(gg.REGION_C_ALLOC)
else
gg.setRanges(gg.REGION_OTHER)
end
gg.searchNumber(user_input, gg.TYPE_BYTE)
count = gg.getResultsCount()
if count == 0 then
found_("O_dinitial_search")
return 0
end
Refiner = gg.getResults(1)
gg.refineNumber(Refiner[1].value, gg.TYPE_BYTE)
count = gg.getResultsCount()
if count == 0 then
found_("O_dinitial_search")
return 0
end
val = gg.getResults(count)
gg.addListItems(val)
end

function CA_pointer_search()
gg.clearResults()
gg.setRanges(gg.REGION_C_ALLOC | gg.REGION_OTHER)
gg.loadResults(gg.getListItems())
gg.searchPointer(offst)
count = gg.getResultsCount()
if count == 0 then
found_("CA_pointer_search")
return 0
end
vel = gg.getResults(count)
gg.clearList()
gg.addListItems(vel)
end

function CA_apply_offset()
if Get_user_input[4] then
tanker = 0xfffffffffffffff8
else
tanker = 0xfffffffffffffff0
end
local copy = false
local l = gg.getListItems()
if not copy then gg.removeListItems(l) end
for i, v in ipairs(l) do
	v.address = v.address + tanker
	if copy then v.name = v.name..' #2' end
end
gg.addListItems(l)
end

function CA2_apply_offset()
if Get_user_input[4] then
tanker = 0xfffffffffffffff8
else
tanker = 0xfffffffffffffff0
end
local copy = false
local l = gg.getListItems()
if not copy then gg.removeListItems(l) end
for i, v in ipairs(l) do
	v.address = v.address + tanker
	if copy then v.name = v.name..' #2' end
end
gg.addListItems(l)
end

function Q_apply_fix()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.loadResults(gg.getListItems())
gg.clearList()
count = gg.getResultsCount()
if count == 0 then
found_("Q_apply_fix")
return 0
end
yy = gg.getResults(1000)
gg.clearResults()
i = 1
c = 1
s = {}
while (i-1) < count do
yy[i].address = yy[i].address + 0xb400000000000000
gg.searchNumber(yy[i].address, gg.TYPE_QWORD)
cnt = gg.getResultsCount()
if 0 < cnt then
bytr = gg.getResults(cnt)
n = 1
while (n-1) < cnt do
s[c] = {}
s[c].address = bytr[n].address
s[c].flags = 32
n = n + 1
c = c + 1
end
end
gg.clearResults()
i = i + 1
end
gg.addListItems(s)
end

function A_base_value()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.loadResults(gg.getListItems())
gg.clearList()
gg.searchPointer(offst)
count = gg.getResultsCount()
if count == 0 then
found_("A_base_value")
return 0
end
tel = gg.getResults(count)
gg.addListItems(tel)
end

function A_base_accuracy()
gg.setRanges(gg.REGION_ANONYMOUS | gg.REGION_C_ALLOC)
gg.loadResults(gg.getListItems())
gg.clearList()
gg.searchPointer(offst)
count = gg.getResultsCount()
if count == 0 then
found_("A_base_accuracy")
return 0
end
kol = gg.getResults(count)
i = 1
h = {}
while (i-1) < count do
h[i] = {}
h[i].address = kol[i].value
h[i].flags = 32
i = i + 1
end
gg.addListItems(h)
end

function A_user_given_offset()
local old_save_list = gg.getListItems()
for i, v in ipairs(old_save_list) do
v.address = v.address + Get_user_input[2]
v.flags = Get_user_type
end
gg.clearResults()
gg.clearList()
gg.loadResults(old_save_list)
count = gg.getResultsCount()
if count == 0 then
found_("Q_apply_fix++")
return 0
end
end

function start()
user_input_taker()
O_initial_search()
O_dinitial_search()
if error > 0 then
return 0
end
CA_pointer_search()
if error > 0 then
return 0
end
CA_apply_offset()
if error > 0 then
return 0
end
A_base_value()
if error > 0 then
return 0
end
if offst == 0 then
A_base_accuracy()
end
if error > 0 then
return 0
end
A_user_given_offset()
if error > 0 then
return 0
end
loopCheck()
if error > 0 then
return 0
end
end

function second_start()
gg.toast("🟡Second Try")
O_dinitial_search()
if error > 1 then
return 0
end
CA_pointer_search()
if error > 1 then
return 0
end
CA_apply_offset()
if error > 1 then
return 0
end
Q_apply_fix()
if error > 1 then
return 0
end
if offst == 0 then
A_base_accuracy()
end
if error > 1 then
return 0
end
A_user_given_offset()
if error > 1 then
return 0
end
loopCheck()
if error > 1 then
return 0
end
end

function third_start()
gg.toast("🔴Third Try")
O_dinitial_search()
if error > 2 then
return 0
end
CA_pointer_search()
if error > 2 then
return 0
end
if offst == 0 then
CA2_apply_offset()
end
if error > 2 then
return 0
end
A_base_value()
if error > 2 then
return 0
end
if offst == 0 then
A_base_accuracy()
end
if error > 2 then
return 0
end
A_user_given_offset()
if error > 2 then
return 0
end
loopCheck()
if error > 2 then
return 0
end
end

function fourth_start()
gg.toast("☢️Fourth Try")
O_dinitial_search()
CA_pointer_search()
CA2_apply_offset()
Q_apply_fix()
if offst == 0 then
A_base_accuracy()
end
A_user_given_offset()
loopCheck()
end

function UI()
gg.showUiButton()
while true do
if gg.isClickedUiButton() then
start()
end
end
end

function TesterLua() end
function setvalue(address,flags,value) TesterLua('Modify address value(Address, value type, value to be modified)')
local tt = {}
tt[1]= {}
tt[1].address = address
tt[1].flags = flags
tt[1].value = value
gg.setValues(tt)
end

on = "🔴⃢  "
off = "    ⃢🟢"

-- race
sec3 = on
sec5 = on
gravity = on
bugstart = on
exitrace = on

gg.setVisible(false)
gg.toast("CLICK GG LOGO")
function HOME()
QR = gg.choice({
[[ 3SEC ]]..sec3, -- 1
[[ 5SEC ]]..sec5, -- 2
[[ 0SEC ]], -- 3
[[ GRAVITY ]]..gravity, -- 4
[[ BUG START ]]..bugstart, -- 5
[[ EXIT RACE ]]..exitrace, -- 6
[[ TELEPORT RACE MENU ]], -- 7
[[ ❌ E X I T ❌ ]],
},nil,os.date[[
┏━━━━━━━✰✰✰━━━━━━━┓
👤Script by: CPM-GG-20
➣ ☀️Today: %m/%d/%y
➣ ⌚Time: %H:%M
┗━━━━━━━✰✰✰━━━━━━━┛
]])
if QR == nil then else
if QR == 1 then if sec3 == on then J1 (on) sec3 = off else J2 (off) sec3 = on end end
if QR == 2 then if sec5 == on then J3 (on) sec5 = off else J4 (off) sec5 = on end end
if QR == 3 then J5() end
if QR == 4 then if gravity == on then J6 (on) gravity = off else J7 (off) gravity = on end end
if QR == 5 then if bugstart == on then J8 (on) bugstart = off else J9 (off) bugstart = on end end
if QR == 6 then if exitrace == on then J10 (on) exitrace = off else J11 (off) exitrace = on end end
if QR == 7 then J12() end
if QR == 8 then EXIT()
end
end
TESTER = -1
end

function J1() -- 3sec on
gg.setVisible(false)
gg.clearResults()
gg.clearList()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber("2500", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
gg.setVisible(false)
revert = gg.getResults(10000, nil, nil, nil, nil, nil, nil, nil, nil)
gg.editAll("-100000", gg.TYPE_FLOAT)
gg.clearResults(100)
gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber("1.1", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
gg.setVisible(false)
revert = gg.getResults(10000, nil, nil, nil, nil, nil, nil, nil, nil)
gg.editAll("3", gg.TYPE_FLOAT)
gg.clearResults(100)
gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber("3.6", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
gg.setVisible(false)
revert = gg.getResults(10000, nil, nil, nil, nil, nil, nil, nil, nil)
gg.editAll("925", gg.TYPE_FLOAT)
gg.clearResults(100)
gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber("10000000", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
gg.setVisible(false)
revert = gg.getResults(10000, nil, nil, nil, nil, nil, nil, nil, nil)
gg.editAll("4E-4", gg.TYPE_FLOAT)
gg.toast("ON")
gg.clearResults()
gg.clearList()
end

function J2() -- 3sec off
gg.setVisible(false)
gg.clearResults()
gg.clearList()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber("-100000", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
gg.setVisible(false)
revert = gg.getResults(10000, nil, nil, nil, nil, nil, nil, nil, nil)
gg.editAll("2500", gg.TYPE_FLOAT)
gg.clearResults(100)
gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber("3", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
gg.setVisible(false)
revert = gg.getResults(10000, nil, nil, nil, nil, nil, nil, nil, nil)
gg.editAll("1.1", gg.TYPE_FLOAT)
gg.clearResults(100)
gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber("925", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
gg.setVisible(false)
revert = gg.getResults(10000, nil, nil, nil, nil, nil, nil, nil, nil)
gg.editAll("3.6", gg.TYPE_FLOAT)
gg.clearResults(100)
gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber("4E-4", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
gg.setVisible(false)
revert = gg.getResults(10000, nil, nil, nil, nil, nil, nil, nil, nil)
gg.editAll("10000000", gg.TYPE_FLOAT)
gg.toast("OFF")
gg.clearResults()
gg.clearList()
end

function J3() -- 5sec on
gg.setVisible(false)
gg.clearResults()
gg.clearList()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber("2500", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
gg.setVisible(false)
revert = gg.getResults(10000, nil, nil, nil, nil, nil, nil, nil, nil)
gg.editAll("-100000", gg.TYPE_FLOAT)
gg.clearResults(100)
gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber("3.6", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
gg.setVisible(false)
revert = gg.getResults(10000, nil, nil, nil, nil, nil, nil, nil, nil)
gg.editAll("30", gg.TYPE_FLOAT)
gg.clearResults(100)
gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber("10000000", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
gg.setVisible(false)
revert = gg.getResults(10000, nil, nil, nil, nil, nil, nil, nil, nil)
gg.editAll("4E-4", gg.TYPE_FLOAT)
gg.toast("ON")
gg.clearResults()
gg.clearList()
end

function J4() -- 5sec off
gg.setVisible(false)
gg.clearResults()
gg.clearList()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber("-100000", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
gg.setVisible(false)
revert = gg.getResults(10000, nil, nil, nil, nil, nil, nil, nil, nil)
gg.editAll("2500", gg.TYPE_FLOAT)
gg.clearResults(100)
gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber("30", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
gg.setVisible(false)
revert = gg.getResults(10000, nil, nil, nil, nil, nil, nil, nil, nil)
gg.editAll("3.6", gg.TYPE_FLOAT)
gg.clearResults(100)
gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber("4E-4", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
gg.setVisible(false)
revert = gg.getResults(10000, nil, nil, nil, nil, nil, nil, nil, nil)
gg.editAll("10000000", gg.TYPE_FLOAT)
gg.toast("OFF")
gg.clearResults()
gg.clearList()
end

function J5() -- 0sec
valueFromClass("MultiDragRacingControll", "0x124", false, false, gg.TYPE_FLOAT)
gg.getResults(9999)
local t = gg.getResults(2)
   gg.addListItems(t)
       t = nil
       gg.setVisible(false)      
          revert = gg.getListItems()
local t = gg.getListItems()
for i, v in ipairs(t) do
    if v.flags == gg.TYPE_FLOAT then
        v.value = "55555"
        v.freeze = false
        v.freezeType = gg.FREEZE_NORMAL
    end
end
gg.addListItems(t)
t = nil

o = gg.getResults(1)

local b = {}
b[1] = {}
b[1].address = o[1].address + 0x18
b[1].flags = gg.TYPE_FLOAT
b[1].value = 9999
b[1].freeze = true
        b[1].freezeType = gg.FREEZE_NORMAL
gg.setValues(b) 
gg.addListItems(b)
b = nil
gg.processResume()

k = gg.getResults(1)

local l = {}
l[1] = {}
l[1].address = k[1].address + 0x4
l[1].flags = gg.TYPE_FLOAT
l[1].value = 00.00
l[1].freeze = true
        l[1].freezeType = gg.FREEZE_NORMAL
gg.setValues(l) 
gg.addListItems(l)
l = nil
gg.processResume()


w = gg.getResults(1)

local q = {}
q[1] = {}
q[1].address = w[1].address + 0xc
q[1].flags = gg.TYPE_FLOAT
q[1].value = 00.00
q[1].freeze = true
        q[1].freezeType = gg.FREEZE_NORMAL
gg.setValues(q) 
gg.addListItems(q)
q = nil
gg.clearResults()
gg.setVisible(false)
gg.toast("ON")
end

function J6() -- gravity on
gg.setVisible(false)
gg.clearResults()
gg.clearList()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber("17170432D;0D;0D;1;-1D:65", gg.TYPE_FLOAT)
gg.setVisible(false)
gg.refineNumber("1", gg.TYPE_FLOAT)
gg.getResults(100)
gg.editAll("8.37547931671", gg.TYPE_FLOAT)
gg.toast("ON")
gg.clearResults()
gg.clearList()
end

function J7() -- gravity off
gg.setVisible(false)
gg.clearResults()
gg.clearList()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber("8.37547931671", gg.TYPE_FLOAT)
gg.setVisible(false)
gg.getResults(100)
gg.editAll("1", gg.TYPE_FLOAT)
gg.toast("OFF")
gg.clearResults()
gg.clearList()
end

function J8() -- bug start on
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x31CA504 setvalue(Tester+Lua,16,-2.74878956e11)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x31CA508 setvalue(Tester+Lua,16,-6.13017998e13)
gg.toast("ON")
end

function J9() -- bug start off
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x31CA504 setvalue(Tester+Lua,16,-3.4632364e10)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x31CA508 setvalue(Tester+Lua,16,-2.8720048e-14)
gg.toast("OFF")
end

function J10() -- exit race on
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x31D8FB4 setvalue(Tester+Lua,16,-2.74878956e11)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x31D8FB8 setvalue(Tester+Lua,16,-6.13017998e13)
gg.toast("ON")
end

function J11() -- exit race off
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x31D8FB4 setvalue(Tester+Lua,16,-1.26612831e34)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x31D8FB8 setvalue(Tester+Lua,16,-2.8720048e-14)
gg.toast("OFF")
end

-- teleport race
function J12()
XMN000 = gg.choice({
[[ BEFORE THE RACE CLICK HERE ]], -- 1
[[ 400M ]], -- 2
[[ 3KM ]], -- 3
[[ ❌ B A C K ❌ ]]
},nil,os.date[[
┏━━━━━━━✰✰✰━━━━━━━┓
👤Script by: CPM-GG-20
➣ ☀️Today: %m/%d/%y
➣ ⌚Time: %H:%M
┗━━━━━━━✰✰✰━━━━━━━┛
]])
if XMN000 == nil then else
if XMN000 == 1 then raceteleport1() end
if XMN000 == 2 then raceteleport2() end
if XMN000 == 3 then raceteleport3() end
if XMN000 == 4 then HOME()
end
end
TESTER = -1
end

function raceteleport1() -- before race
gg.setVisible(false)
gg.clearResults()
gg.clearList()
gg.setRanges(32)
gg.searchNumber("-0.10000000149;-10;49", 16)
gg.setVisible(false)
gg.refineNumber("-0.10000000149", 16)
gg.getResults(1)
gg.toast("ON")
end

function raceteleport2() -- teleport 400m
gg.setVisible(false)
gg.alert ("CLICK GG LOGO FOR ON")
while true do
if gg.isVisible() then
break
else
gg.sleep(50)
end end gg.setVisible(false)
gg.setRanges(32)
gg.editAll("-400", 16)
gg.toast("ON")
end

function raceteleport3() -- teleport 3km
gg.setVisible(false)
gg.alert ("CLICK GG LOGO FOR ON")
while true do
if gg.isVisible() then
break
else
gg.sleep(50)
end end gg.setVisible(false)
gg.setRanges(32)
gg.editAll("-3000", 16)
gg.toast("ON")
end

function EXIT()
gg.toast("EXIT ✔")
gg.clearResults()
gg.clearList()
os.exit()
end 

while true do
if gg.isVisible(true) then
TESTER = 1
gg.setVisible(false)
end
if TESTER == 1 then
HOME()
end
end

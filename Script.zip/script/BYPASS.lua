
GLabel = 'Car Parking'
GProcess = 'com.olzhas.carparking.multyplayer'
GVersion = '4.8.20.4'

local v = gg.getTargetInfo()
if v.processName~=GProcess then
gg.alert("This Script is For:\n"..GLabel.."\n"..GProcess.."\n\nYou Selected:\n"..v.label.."\n"..v.processName)
os.exit()
return
end

if GVersion~=v.versionName then
gg.alert("This Script is for Game Version:\n"..GVersion.."\n\nYour Game Version is:\n"..v.versionName) 
gg.setVisible(false)
os.exit() 
return
end

function TesterLua() end
function setvalue(address,flags,value) TesterLua('Modify address value(Address, value type, value to be modified)')
local tt = {}
tt[1]= {}
tt[1].address = address
tt[1].flags = flags
tt[1].value = value
gg.setValues(tt)
end

on = "🔴⃢  "
off = "    ⃢🟢"

-- bypass
worldsale = on
disabledrace = on
cheatingforbiden = on
cheatingvisualdetect = on
vinyalsforbiden = on
bypassserver = on

gg.setVisible(false)
gg.toast("CLICK GG LOGO")
function HOME()
QR = gg.choice({
[[ BYPASS WORLD SALE ]]..worldsale, -- 1
[[ NO RACE DISABLED ]]..disabledrace, -- 2
[[ NO DETECT FORBIDEN NAME ]]..cheatingforbiden, -- 3
[[ NO DETECT VISUAL CHEATING ]]..cheatingvisualdetect, -- 4
[[ NO DETECT FORBIDEN VINYALS ]]..vinyalsforbiden, -- 5
[[ BYPASS SERVER ]]..bypassserver, -- 6
[[ ❌ E X I T ❌ ]]
},nil,os.date[[
┏━━━━━━━✰✰✰━━━━━━━┓
👤Script by: CPM-GG-20
➣ ☀️Today: %m/%d/%y
➣ ⌚Time: %H:%M
┗━━━━━━━✰✰✰━━━━━━━┛
]])
if QR == nil then else
if QR == 1 then if worldsale == on then by1 (on) worldsale = off else by2 (off) worldsale = on end end
if QR == 2 then if disabledrace == on then by3 (on) disabledrace = off else by4 (off) disabledrace = on end end
if QR == 3 then if cheatingforbiden == on then by5 (on) cheatingforbiden = off else by6 (off) cheatingforbiden = on end end
if QR == 4 then if cheatingvisualdetect == on then by7 (on) cheatingvisualdetect = off else by8 (off) cheatingvisualdetect = on end end
if QR == 5 then if vinyalsforbiden == on then by9 (on) vinyalsforbiden = off else by10 (off) vinyalsforbiden = on end end
if QR == 6 then if bypassserver == on then by11 (on) bypassserver = off else by12 (off) bypassserver = on end end
if QR == 7 then EXIT()
end
end
TESTER = -1
end


function by1() -- bypass world sale on
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x290CB90 setvalue(Tester+Lua,16,-2.74878956e11)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x290CB94 setvalue(Tester+Lua,16,-6.13017998e13)
gg.toast("G𝗢 𝗧𝗢 𝗟E𝗩E𝗟 𝗔𝗡𝗗 𝗖𝗢ME BACK")
end

function by2() -- bypass world sale off
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x290CB90 setvalue(Tester+Lua,16,-1.27424102e34)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x290CB94 setvalue(Tester+Lua,16,-2.87131023e-14)
gg.toast("OFF")
end

function by3() -- no race disabled on
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x3AD9C5C setvalue(Tester+Lua,16,-2.74877907e11)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x3AD9C60 setvalue(Tester+Lua,16,-6.13017998e13)
gg.toast("ON")
end

function by4() -- no race disables off
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x3AD9C5C setvalue(Tester+Lua,16,-1.26612831e34)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x3AD9C60 setvalue(Tester+Lua,16,-2.8720048e-14)
gg.toast("OFF")
end

function by5() -- no detect forbiden name on
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x3ADA6AC setvalue(Tester+Lua,16,-2.74877907e11)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x3ADA6B0 setvalue(Tester+Lua,16,-6.13017998e13)
gg.toast("ON")
end

function by6() -- no detect forbiden name off
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x3ADA6AC setvalue(Tester+Lua,16,-1.28235374e34)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x3ADA6B0 setvalue(Tester+Lua,16,-2.87512967e-14)
gg.toast("OFF")
end

function by7() -- no detect visual cheating on
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x3ADA394 setvalue(Tester+Lua,16,-2.74877907e11)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x3ADA398 setvalue(Tester+Lua,16,-6.13017998e13)
gg.toast("ON")
end

function by8() -- no detect visual cheating off
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x3ADA394 setvalue(Tester+Lua,16,-3.49007995e10)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x3ADA398 setvalue(Tester+Lua,16,2.55596463e27)
gg.toast("OFF")
end

function by9() -- no detect vinyals forbiden on
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x3ADA72C setvalue(Tester+Lua,16,-2.74877907e11)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x3ADA730 setvalue(Tester+Lua,16,-6.13017998e13)
gg.toast("ON")
end

function by10() -- no detect vinyals forbiden off
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x3ADA72C setvalue(Tester+Lua,16,-6.23126725e34)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x3ADA730 setvalue(Tester+Lua,16,-1.41233826e-13)
gg.toast("OFF")
end

function by11() -- bypass server on
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x280E180 setvalue(Tester+Lua,16,-2.74877907e11)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x3AD9BB4 setvalue(Tester+Lua,16,-6.13017998e13)
gg.toast("ON")
end

function by12() -- bypass server off
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x280E180 setvalue(Tester+Lua,16,-6.23126725e34)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x3AD9BB4 setvalue(Tester+Lua,16,-1.41233826e-13)
gg.toast("OFF")
end

function EXIT()
gg.toast("EXIT ✔")
gg.clearResults()
gg.clearList()
os.exit()
end 

while true do
if gg.isVisible(true) then
TESTER = 1
gg.setVisible(false)
end
if TESTER == 1 then
HOME()
end
end

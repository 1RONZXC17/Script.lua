
GLabel = 'Car Parking'
GProcess = 'com.olzhas.carparking.multyplayer'
GVersion = '4.8.20.4'

local v = gg.getTargetInfo()
if v.processName~=GProcess then
gg.alert("This Script is For:\n"..GLabel.."\n"..GProcess.."\n\nYou Selected:\n"..v.label.."\n"..v.processName)
os.exit()
return
end

if GVersion~=v.versionName then
gg.alert("This Script is for Game Version:\n"..GVersion.."\n\nYour Game Version is:\n"..v.versionName) 
gg.setVisible(false)
os.exit() 
return
end

on = "🔴⃢  "
off = "    ⃢🟢"

-- graphics
nightmode = on
graphics1m = on
graphics2m = on
snowing = on

gg.setVisible(false)
gg.toast("CLICK GG LOGO")
function HOME()
QR = gg.choice({
[[ NIGHT MODE ]]..nightmode, -- 1
[[ GRAPHICS ]]..graphics1m, -- 2
[[ CUSTOM GRAPHICS ]]..graphics2m, -- 3
[[ SNOWING EFFECT ]]..snowing, -- 4
[[ ❌ E X I T ❌ ]],
},nil,os.date[[
┏━━━━━━━✰✰✰━━━━━━━┓
👤Script by: CPM-GG-20
➣ ☀️Today: %m/%d/%y
➣ ⌚Time: %H:%M
┗━━━━━━━✰✰✰━━━━━━━┛
]])
if QR == nil then else
if QR == 1 then if nightmode == on then graphics1 (on) nightmode = off else graphics2 (off) nightmode = on end end
if QR == 2 then if graphics1m == on then graphics3 (on) graphics1m = off else graphics4 (off) graphics1m = on end end
if QR == 3 then if graphics2m == on then graphics5 (on) graphics2m = off else graphics6 (off) graphics2m = on end end
if QR == 4 then if snowing == on then graphics7 (on) snowing = off else graphics8 (off) snowing = on end end
if QR == 5 then EXIT()
end
end
TESTER = -1
end

function graphics1() -- night mode on
gg.clearResults()
gg.clearList()
gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber("1,008,981,770;-971,227,136:5", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
gg.refineNumber("1,008,981,770;-971,227,136", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
revert = gg.getResults(9999, nil, nil, nil, nil, nil, nil, nil, nil)
gg.editAll("-971,227,136;-1", gg.TYPE_DWORD)
gg.toast("ON")
gg.clearResults()
gg.clearList()
end

function graphics2() -- night mode off
gg.clearResults()
gg.clearList()
gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber("-971,227,136;-1", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
revert = gg.getResults(9999, nil, nil, nil, nil, nil, nil, nil, nil)
gg.editAll("1,008,981,770;-971,227,136", gg.TYPE_DWORD)
gg.toast("OFF")
gg.clearResults()
gg.clearList()
end

function graphics3() -- graphics on
gg.clearResults()
gg.clearList()
gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber("2.20000004768", 16)
revert = gg.getResults(9999, nil, nil, nil, nil, nil, nil, nil, nil)
gg.editAll("10", 16)
gg.toast("ON")
gg.clearResults()
gg.clearList()
end

function graphics4() -- graphics off
gg.clearResults()
gg.clearList()
gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber("10", 16)
revert = gg.getResults(9999, nil, nil, nil, nil, nil, nil, nil, nil)
gg.editAll("2.20000004768", 16)
gg.toast("OFF")
gg.clearResults()
gg.clearList()
end

function graphics5() -- custom graphics on
gg.clearResults()
gg.clearList()
local graphics = gg.prompt({
"﻿⚠️YOU DON'T HAVE TO CHANGE THE NUMBER [2.20000004768]⚠️️",
"EDIT GRAPHICS",
"BACK",
},{"2.20000004768",""},{"number","number","checkbox"})
if graphics == nil then else
if not graphics then return end
if graphics[3] then ONECV18() end

gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber(","..graphics[1].."" , 16)
revert = gg.getResults(9999, nil, nil, nil, nil, nil, nil, nil, nil)
gg.editAll(","..graphics[2].."" , 16)
gg.toast("ON")
gg.clearResults()
gg.clearList()
end
end

function graphics6() -- custom graphics off
gg.clearResults()
gg.clearList()
local graphics = gg.prompt({
"﻿ENTER THE NUMBER YOU CHOASE FIRST",
"﻿⚠️YOU DON'T HAVE TO CHANGE THE NUMBER [2.20000004768]⚠️️",
"BACK",
},{"","2.20000004768"},{"number","number","checkbox"})
if graphics == nil then else
if not graphics then return end
if graphics[3] then ONECV18() end

gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber(","..graphics[1].."" , 16)
revert = gg.getResults(9999, nil, nil, nil, nil, nil, nil, nil, nil)
gg.editAll(","..graphics[2].."" , 16)
gg.toast("OFF")
gg.clearResults()
gg.clearList()
end
end

function graphics7() -- snowing off
gg.clearResults()
gg.clearList()
gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber("1000", 16)
revert = gg.getResults(9999, nil, nil, nil, nil, nil, nil, nil, nil)
gg.editAll("-9999", 16)
gg.toast("ON")
gg.clearResults()
gg.clearList()
end

function graphics8() -- snowing off
gg.clearResults()
gg.clearList()
gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber("-9999", 16)
revert = gg.getResults(9999, nil, nil, nil, nil, nil, nil, nil, nil)
gg.editAll("1000", 16)
gg.toast("ON")
gg.clearResults()
gg.clearList()
end

function EXIT()
gg.toast("EXIT ✔")
gg.clearResults()
gg.clearList()
os.exit()
end 

while true do
if gg.isVisible(true) then
TESTER = 1
gg.setVisible(false)
end
if TESTER == 1 then
HOME()
end
end

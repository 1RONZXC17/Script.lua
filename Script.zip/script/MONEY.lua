
GLabel = 'Car Parking'
GProcess = 'com.olzhas.carparking.multyplayer'
GVersion = '4.8.20.4'

local v = gg.getTargetInfo()
if v.processName~=GProcess then
gg.alert("This Script is For:\n"..GLabel.."\n"..GProcess.."\n\nYou Selected:\n"..v.label.."\n"..v.processName)
os.exit()
return
end

if GVersion~=v.versionName then
gg.alert("This Script is for Game Version:\n"..GVersion.."\n\nYour Game Version is:\n"..v.versionName) 
gg.setVisible(false)
os.exit() 
return
end

function TesterLua() end
function setvalue(address,flags,value) TesterLua('Modify address value(Address, value type, value to be modified)')
local tt = {}
tt[1]= {}
tt[1].address = address
tt[1].flags = flags
tt[1].value = value
gg.setValues(tt)
end

on = "🔴⃢  "
off = "    ⃢🟢"

-- money
sendmoney = on
freezemoney = on

gg.setVisible(false)
gg.toast("CLICK GG LOGO")
function HOME()
QR = gg.choice({
[[ GET 1B MONEY ]], -- 1
[[ GET 50M MONEY ]], -- 2
[[ GET 30M MONEY ]], -- 3
[[ CUSTOM MONEY ]], -- 4
[[ SEND MONEY ]]..sendmoney, -- 5
[[ FREEZE MONEY ]]..freezemoney, -- 6
[[ ❌ E X I T ❌ ]],
},nil,os.date[[
┏━━━━━━━✰✰✰━━━━━━━┓
👤Script by: CPM-GG-20
➣ ☀️Today: %m/%d/%y
➣ ⌚Time: %H:%M
┗━━━━━━━✰✰✰━━━━━━━┛
]])
if QR == nil then else
if QR == 1 then money1() end
if QR == 2 then money2() end
if QR == 3 then money3() end
if QR == 4 then money4() end
if QR == 5 then if sendmoney == on then money5 (on) sendmoney = off else money6 (off) sendmoney = on end end
if QR == 6 then if freezemoney == on then money7 (on) freezemoney = off else money8 (off) freezemoney = on end end
if QR == 7 then EXIT()
end
end
TESTER = -1
end

function money1() -- get 1b money
gg.setVisible(false)
gg.alert ("CLICK LEVEL 3 THEN CLICK ON THE GG LOGO TO START")
gg.clearResults()
gg.clearList()
while true do
if gg.isVisible() then
break
else
gg.sleep(50)
end end gg.setVisible(false) gg.clearResults()
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5D28E08 setvalue(Tester+Lua,16,1917191729192019001910)
gg.setRanges(32)
gg.searchNumber("40", 16)
gg.getResults(9999)
gg.editAll("50000000", 16)
gg.alert ("CLICK LEVEL 1")
gg.toast("ON")
gg.clearResults()
gg.clearList()
end

function money2() -- get 50m money
gg.setVisible(false)
gg.alert ("CLICK LEVEL 3 THEN CLICK ON THE GG LOGO TO START")
gg.clearResults()
gg.clearList()
while true do
if gg.isVisible() then
break
else
gg.sleep(50)
end end gg.setVisible(false) gg.clearResults()
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5D28E08 setvalue(Tester+Lua,16,50000000)
gg.setRanges(32)
gg.searchNumber("40", 16)
gg.getResults(9999)
gg.editAll("50000000", 16)
gg.alert ("CLICK LEVEL 1")
gg.toast("ON")
gg.clearResults()
gg.clearList()
end

function money3() -- get 30m money
gg.setVisible(false)
gg.alert ("CLICK LEVEL 3 THEN CLICK ON THE GG LOGO TO START")
gg.clearResults()
gg.clearList()
while true do
if gg.isVisible() then
break
else
gg.sleep(50)
end end gg.setVisible(false) gg.clearResults()
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5D28E08 setvalue(Tester+Lua,16,30000000)
gg.setRanges(32)
gg.searchNumber("40", 16)
gg.getResults(9999)
gg.editAll("50000000", 16)
gg.alert ("CLICK LEVEL 1")
gg.toast("ON")
gg.clearResults()
gg.clearList()
end

function money4() -- custom money
gg.setVisible(false)
gg.alert ("CLICK LEVEL 3 THEN CLICK ON THE GG LOGO TO START")
gg.clearResults()
gg.clearList()
while true do
if gg.isVisible() then
break
else
gg.sleep(50)
end end gg.setVisible(false) gg.clearResults()
d=gg.prompt({"CUSTOM MONEY","BACK"},nil,{"number","checkbox"})
if d[2] then HOME() end
if not d then return end
if d == nil then Menu() end
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5D28E08 setvalue(Tester+Lua,16,d[1])
gg.setRanges(32)
gg.searchNumber("40", 16)
gg.getResults(9999)
gg.editAll("50000000", 16)
gg.alert ("CLICK LEVEL 1")
gg.toast("ON")
gg.clearResults()
gg.clearList()
end

function money5() -- send money on
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5C85848 setvalue(Tester+Lua,16,1.40129846e-38)
gg.toast("SEND MONEY 1000")
end

function money6() -- send money off
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5C85848 setvalue(Tester+Lua,16,2.24207754e-44)
gg.toast("OFF")
end

function money7() -- freeze money on
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x2B332F4 setvalue(Tester+Lua,16,-2.74878956e11)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x2B332F8 setvalue(Tester+Lua,16,-6.13017998e13)
gg.toast("ON")
end

function money8() -- freeze money off
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x2B332F4 setvalue(Tester+Lua,16,-3.51692349e10)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x2B332F8 setvalue(Tester+Lua,16,-2.55656968e27)
gg.toast("OFF")
end

function EXIT()
gg.toast("EXIT ✔")
gg.clearResults()
gg.clearList()
os.exit()
end 

while true do
if gg.isVisible(true) then
TESTER = 1
gg.setVisible(false)
end
if TESTER == 1 then
HOME()
end
end

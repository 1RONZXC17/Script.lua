
GLabel = 'Car Parking'
GProcess = 'com.olzhas.carparking.multyplayer'
GVersion = '4.8.20.4'

local v = gg.getTargetInfo()
if v.processName~=GProcess then
gg.alert("This Script is For:\n"..GLabel.."\n"..GProcess.."\n\nYou Selected:\n"..v.label.."\n"..v.processName)
os.exit()
return
end

if GVersion~=v.versionName then
gg.alert("This Script is for Game Version:\n"..GVersion.."\n\nYour Game Version is:\n"..v.versionName) 
gg.setVisible(false)
os.exit() 
return
end

function TesterLua() end
function setvalue(address,flags,value) TesterLua('Modify address value(Address, value type, value to be modified)')
local tt = {}
tt[1]= {}
tt[1].address = address
tt[1].flags = flags
tt[1].value = value
gg.setValues(tt)
end

gg.setVisible(false)
gg.toast("CLICK GG LOGO")
function HOME()
QR = gg.choice({
[[ • UNLOCK CAR MENU ]], -- 1
[[ ❌ E X I T ❌ ]],
},nil,os.date[[
┏━━━━━━━✰✰✰━━━━━━━┓
👤Script by: CPM-GG-20
➣ ☀️Today: %m/%d/%y
➣ ⌚Time: %H:%M
┗━━━━━━━✰✰✰━━━━━━━┛
]])
if QR == nil then else
if QR == 1 then ONECV1() end
if QR == 2 then EXIT()
end
end
TESTER = -1
end

-- unlock car menu
function ONECV1()
XMN000 = gg.choice({
[[ PREMIUM CAR MENU ]], -- 1
[[ LAMBORGHINI CAR MENU ]], -- 2
[[ HUMMER H1 ]], -- 3
[[ ❌ B A C K ❌ ]]
},nil,os.date[[
┏━━━━━━━✰✰✰━━━━━━━┓
👤Script by: CPM-GG-20
➣ ☀️Today: %m/%d/%y
➣ ⌚Time: %H:%M
┗━━━━━━━✰✰✰━━━━━━━┛
]])
if XMN000 == nil then else
if XMN000 == 1 then unlockcar1() end
if XMN000 == 2 then unlockcar2() end
if XMN000 == 3 then unlockcar3() end
if XMN000 == 4 then HOME()
end
end
TESTER = -1
end

function unlockcar1() -- premium car menu
gg.setVisible(false)
gg.clearResults()
gg.clearList()
d = gg.prompt({"NISSAN 350Z","NISSAN 240SX","TOYOTA CARMY","SKYLINE R32","BMW M2","BMW X6","M4 G82","M5 F90","MERCEDES","DODGE VIPER","MERCEDES","MERCEDES","BMW M8","F1","BMW I8","BUGGY","F2","BACK"},nil,{"checkbox","checkbox","checkbox","checkbox","checkbox","checkbox","checkbox","checkbox","checkbox","checkbox","checkbox","checkbox","checkbox","checkbox","checkbox","checkbox","checkbox","checkbox","checkbox"})
if not d then return end if d == nil then Menu() end

if d[1] then -- nissan 350z
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5C85978 setvalue(Tester+Lua,4,325)
gg.alert("SEARCH FOR CAR 89 AND BUY")
gg.toast("ON")
end

if d[2] then -- nissan 240sx
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5C85978 setvalue(Tester+Lua,4,305)
gg.alert("SEARCH FOR CAR 89 AND BUY")
gg.toast("ON")
end

if d[3] then -- toyota carmy
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5C85978 setvalue(Tester+Lua,4,288)
gg.alert("SEARCH FOR CAR 89 AND BUY")
gg.toast("ON")
end

if d[4] then -- skyline R32
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5C85978 setvalue(Tester+Lua,4,342)
gg.alert("SEARCH FOR CAR 89 AND BUY")
gg.toast("ON")
end

if d[5] then -- bmw m2
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5C85978 setvalue(Tester+Lua,4,295)
gg.alert("SEARCH FOR CAR 89 AND BUY")
gg.toast("ON")
end

if d[6] then -- bmw x6
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5C85978 setvalue(Tester+Lua,4,280)
gg.alert("SEARCH FOR CAR 89 AND BUY")
gg.toast("ON")
end

if d[7] then -- bmw m4 g82
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5C85978 setvalue(Tester+Lua,4,339)
gg.alert("SEARCH FOR CAR 89 AND BUY")
gg.toast("ON")
end

if d[8] then -- m5 f90
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5C85978 setvalue(Tester+Lua,4,260)
gg.alert("SEARCH FOR CAR 89 AND BUY")
gg.toast("ON")
end

if d[9] then -- mercedes
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5C85978 setvalue(Tester+Lua,4,276)
gg.alert("SEARCH FOR CAR 89 AND BUY")
gg.toast("ON")
end

if d[10] then -- dodge viper
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5C85978 setvalue(Tester+Lua,4,321)
gg.alert("SEARCH FOR CAR 89 AND BUY")
gg.toast("ON")
end

if d[11] then -- mercedes
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5C85978 setvalue(Tester+Lua,4,310)
gg.alert("SEARCH FOR CAR 89 AND BUY")
gg.toast("ON")
end

if d[12] then -- mercedes
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5C85978 setvalue(Tester+Lua,4,322)
gg.alert("SEARCH FOR CAR 89 AND BUY")
gg.toast("ON")
end

if d[13] then -- bmw m8
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5C85978 setvalue(Tester+Lua,4,324)
gg.alert("SEARCH FOR CAR 89 AND BUY")
gg.toast("ON")
end

if d[14] then -- f1
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5C85978 setvalue(Tester+Lua,4,341)
gg.alert("SEARCH FOR CAR 89 AND BUY")
gg.toast("ON")
end

if d[15] then -- bmw i8
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5C85978 setvalue(Tester+Lua,4,312)
gg.alert("SEARCH FOR CAR 89 AND BUY")
gg.toast("ON")
end

if d[16] then -- buggy
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5C85978 setvalue(Tester+Lua,4,356)
gg.alert("SEARCH FOR CAR 89 AND BUY")
gg.toast("ON")
end

if d[17] then -- f2
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5C85978 setvalue(Tester+Lua,4,357)
gg.alert("SEARCH FOR CAR 89 AND BUY")
gg.toast("ON")
end

if d[18] then -- back
ONECV1()
end
end

function unlockcar2() -- Lamborghini menu
gg.setVisible(false)
gg.clearResults()
gg.clearList()
d = gg.prompt({"HURACAN","AVENTADOR","VENENO","GALLARDO","SVJ","URUS","BACK"},nil,{"checkbox","checkbox","checkbox","checkbox","checkbox","checkbox","checkbox"})
if not d then return end if d == nil then Menu() end

if d[1] then -- huracan
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5C85978 setvalue(Tester+Lua,4,25)
gg.alert("SEARCH FOR CAR 89 AND BUY")
gg.toast("ON")
end

if d[2] then -- aventador
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5C85978 setvalue(Tester+Lua,4,66)
gg.alert("SEARCH FOR CAR 89 AND BUY")
gg.toast("ON")
end

if d[3] then -- veneno
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5C85978 setvalue(Tester+Lua,4,68)
gg.alert("SEARCH FOR CAR 89 AND BUY")
gg.toast("ON")
end

if d[4] then -- gallardo
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5C85978 setvalue(Tester+Lua,4,101)
gg.alert("SEARCH FOR CAR 89 AND BUY")
gg.toast("ON")
end

if d[5] then -- svj
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5C85978 setvalue(Tester+Lua,4,345)
gg.alert("SEARCH FOR CAR 89 AND BUY")
gg.toast("ON")
end

if d[6] then -- urus
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5C85978 setvalue(Tester+Lua,4,293)
gg.alert("SEARCH FOR CAR 89 AND BUY")
gg.toast("ON")
end

if d[7] then -- back
ONECV1()
end
end

function unlockcar3() -- hummer h1
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x5C85978 setvalue(Tester+Lua,4,281)
gg.alert("SEARCH FOR CAR 89 AND BUY")
gg.toast("ON")
end

function EXIT()
gg.toast("EXIT ✔")
gg.clearResults()
gg.clearList()
os.exit()
end 

while true do
if gg.isVisible(true) then
TESTER = 1
gg.setVisible(false)
end
if TESTER == 1 then
HOME()
end
end

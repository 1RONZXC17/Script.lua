
GLabel = 'Car Parking'
GProcess = 'com.olzhas.carparking.multyplayer'
GVersion = '4.8.20.4'

local v = gg.getTargetInfo()
if v.processName~=GProcess then
gg.alert("This Script is For:\n"..GLabel.."\n"..GProcess.."\n\nYou Selected:\n"..v.label.."\n"..v.processName)
os.exit()
return
end

if GVersion~=v.versionName then
gg.alert("This Script is for Game Version:\n"..GVersion.."\n\nYour Game Version is:\n"..v.versionName) 
gg.setVisible(false)
os.exit() 
return
end

function TesterLua() end
function setvalue(address,flags,value) TesterLua('Modify address value(Address, value type, value to be modified)')
local tt = {}
tt[1]= {}
tt[1].address = address
tt[1].flags = flags
tt[1].value = value
gg.setValues(tt)
end

on = "🔴⃢  "
off = "    ⃢🟢"

-- prank
bobol = on
teleport = on
dance1 = on
dance2 = on
dance3 = on
loadcar = on
roller = on

gg.setVisible(false)
gg.toast("CLICK GG LOGO")
function HOME()
QR = gg.choice({
[[ BOBOL MOBIL ]]..bobol, -- 1
[[ TELEPORT ]]..teleport, -- 2
[[ DANCE (1) ]]..dance1, -- 3
[[ DANCE (2) ]]..dance2, -- 4
[[ DANCE (3) ]]..dance3, -- 5
[[ BUY CAR 0$ ]], -- 6
[[ LOAD CAR ]]..loadcar, -- 7
[[ CAR ROLLER ]]..roller, -- 8
[[ CUSTOM NAME IN ROOM ]], -- 9
[[ ❌ E X I T ❌ ]],
},nil,os.date[[
┏━━━━━━━✰✰✰━━━━━━━┓
👤Script by: CPM-GG-20
➣ ☀️Today: %m/%d/%y
➣ ⌚Time: %H:%M
┗━━━━━━━✰✰✰━━━━━━━┛
]])
if QR == nil then else
if QR == 1 then if bobol == on then F1 (on) bobol = off else F2 (off) bobol = on end end
if QR == 2 then if teleport == on then F3 (on) teleport = off else F4 (off) teleport = on end end
if QR == 3 then if dance1 == on then F5 (on) dance1 = off else F6 (off) dance1 = on end end
if QR == 4 then if dance2 == on then F7 (on) dance2 = off else F8 (off) dance2 = on end end
if QR == 5 then if dance3 == on then F9 (on) dance3 = off else F10 (off) dance3 = on end end
if QR == 6 then F11() end
if QR == 7 then if loadcar == on then F12 (on) loadcar = off else F13 (off) loadcar = on end end
if QR == 8 then if roller == on then F14 (on) roller = off else F15 (off) roller = on end end
if QR == 9 then F16() end
if QR == 10 then EXIT()
end
end
TESTER = -1
end

function F1() -- bobol mobil on
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x29EAFFC setvalue(Tester+Lua,16,-2.74878956e11)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x29EB000 setvalue(Tester+Lua,16,-6.13017998e13)
gg.toast("ON")
end

function F2() -- bobol mobil off
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x29EAFFC setvalue(Tester+Lua,16,-3.4632364e10)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x29EB000 setvalue(Tester+Lua,16,-2.8720048e-14)
gg.toast("OFF")
end

function F3() -- teleport on
gg.setVisible(false)
gg.clearResults()
gg.clearList()
gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber("100", gg.TYPE_FLOAT)
gg.setVisible(false)
gg.getResults(48)
gg.editAll("1000", gg.TYPE_FLOAT)
gg.toast("ON")
gg.clearResults()
gg.clearList()
end

function F4() -- teleport off
gg.setVisible(false)
gg.clearResults()
gg.clearList()
gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber("1000", gg.TYPE_FLOAT)
gg.setVisible(false)
gg.getResults(48)
gg.editAll("100", gg.TYPE_FLOAT)
gg.toast("OFF")
gg.clearResults()
gg.clearList()
end

function F5() -- dance 1 on
Tester=gg.getRangesList('libunity.so')[2].start
Lua=0xF5905C setvalue(Tester+Lua,16,-999)
gg.toast("ON")
end

function F6() -- dance 1 off
Tester=gg.getRangesList('libunity.so')[2].start
Lua=0xF5905C setvalue(Tester+Lua,16,1E7)
gg.toast("OFF")
end

function F7() -- dance 2 on
Tester=gg.getRangesList('libunity.so')[2].start
Lua=0xF5905C setvalue(Tester+Lua,16,-20000000)
gg.toast("ON")
end

function F8() -- dance 2 off
Tester=gg.getRangesList('libunity.so')[2].start
Lua=0xF5905C setvalue(Tester+Lua,16,1E7)
gg.toast("OFF")
end

function F9() -- dance 3 on
Tester=gg.getRangesList('libunity.so')[2].start
Lua=0xF5905C setvalue(Tester+Lua,16,-1)
gg.toast("ON")
end

function F10() -- dance 3 off
Tester=gg.getRangesList('libunity.so')[2].start
Lua=0xF5905C setvalue(Tester+Lua,16,1E7)
gg.toast("OFF")
end

function F11() -- buy car in 0$
gg.setVisible(false)
gg.clearResults()
gg.clearList()
gg.setRanges(32)
d=gg.prompt({"ENTER THE PRICE","BACK"},nil,{"number","checkbox"}) if not d then return end if d == nil then Menu() end gg.clearResults() gg.setVisible(false) if d[2] then return gg.setVisible(true) end
gg.setRanges(gg.REGION_ANONYMOUS)
xor = d[1].."x4"
gg.searchNumber(xor,4)
gg.getResults(100)
gg.editAll("0x4", 4)
gg.toast("ON")
gg.clearResults()
gg.clearList()
end

function F12() -- load car on
gg.setVisible(false)
gg.clearResults()
gg.clearList()
gg.setRanges(32)
gg.searchNumber("2.4611913E-38;-10.0;3.40282347E38:65", 16)
gg.setVisible(false)
gg.refineNumber("-10", 16)
gg.getResults(1000)
gg.editAll("999.9", 16)
gg.toast("ON")
gg.clearResults()
gg.clearList()
end

function F13() -- load car off
gg.setVisible(false)
gg.clearResults()
gg.clearList()
gg.setRanges(32)
gg.searchNumber("999.9", 16)
gg.setVisible(false)
gg.getResults(1000)
gg.editAll("-10", 16)
gg.toast("OFF")
gg.clearResults()
gg.clearList()
end

function F14() -- car roller on
gg.clearResults()
gg.clearList()
gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber("2000", 16)
revert = gg.getResults(8769, nil, nil, nil, nil, nil, nil, nil, nil)
local t = gg.getResults(8769, nil, nil, nil, nil, nil, nil, nil, nil)
for i, v in ipairs(t) do
	if v.flags == 16 then
		v.value = "-9999"
		v.freeze = true
	end
end
gg.addListItems(t)
t = nil
gg.toast("ON")
gg.clearResults()
gg.clearList()
end

function F15() -- car roller off
gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber("-9999", 16)

revert = gg.getResults(8769, nil, nil, nil, nil, nil, nil, nil, nil)
local t = gg.getResults(8769, nil, nil, nil, nil, nil, nil, nil, nil)
for i, v in ipairs(t) do
	if v.flags == 16 then
		v.value = "2000"
		v.freeze = true
	end
end
gg.addListItems(t)
t = nil
gg.toast("OFF")
gg.clearResults()
gg.clearList()
end

function F16() -- custom name in room
gg.clearResults()
gg.clearList()
gg.alert("⚠️FIRST ENTER YOUR NICKNAME⚠️\n\n⚠️️SECOND EDIT NICKNAME⚠️️")

gg.clearResults()
gg.clearList()
local name = gg.prompt({
"﻿⚠️YOU DON'T HAVE TO CHANGE THE [ ; ]⚠️️",
"﻿⚠️YOU DON'T HAVE TO CHANGE THE [ ; ]⚠️️",
"BACK",
},{";",";"},{"text","text","checkbox"})
if name == nil then else
if not name then return end
if name[3] then HOME() end

gg.setRanges(32)
gg.searchNumber(","..name[1].."" , 2)
revert = gg.getResults(9999, nil, nil, nil, nil, nil, nil, nil, nil)
gg.editAll(","..name[2].."" , 2)
gg.clearResults()
gg.clearList()
gg.setRanges(32)
gg.searchNumber("12;1041009805:21", gg.TYPE_DWORD)
gg.refineNumber("12", gg.TYPE_DWORD)
gg.processResume()
local t = gg.getResults(8769, nil, nil, nil, nil, nil, nil, nil, nil)
gg.addListItems(t)
gg.clearResults()
t = nil
revert = gg.getListItems()
local t = gg.getListItems()
for i, v in ipairs(t) do
	if v.flags == 4 then
		v.value = "99999"
		v.freeze = true
		v.freezeType = gg.FREEZE_NORMAL
	end
end
gg.addListItems(t)
t = nil
gg.toast("ON")
gg.clearResults()
gg.clearList()
end
end

function EXIT()
gg.toast("EXIT ✔")
gg.clearResults()
gg.clearList()
os.exit()
end 

while true do
if gg.isVisible(true) then
TESTER = 1
gg.setVisible(false)
end
if TESTER == 1 then
HOME()
end
end

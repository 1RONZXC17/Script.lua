
GLabel = 'Car Parking'
GProcess = 'com.olzhas.carparking.multyplayer'
GVersion = '4.8.20.4'

local v = gg.getTargetInfo()
if v.processName~=GProcess then
gg.alert("This Script is For:\n"..GLabel.."\n"..GProcess.."\n\nYou Selected:\n"..v.label.."\n"..v.processName)
os.exit()
return
end

if GVersion~=v.versionName then
gg.alert("This Script is for Game Version:\n"..GVersion.."\n\nYour Game Version is:\n"..v.versionName) 
gg.setVisible(false)
os.exit() 
return
end

function search(class, offset, tryHard, bit32, valueType)
Get_user_input = {}
Get_user_input[1] = class
Get_user_input[2] = offset
Get_user_input[3] = tryHard
Get_user_input[4] = bit32
Get_user_type = valueType
start()
end

function loopCheck()
if userMode == 1 then
UI()
elseif error == 3 then
os.exit()
end
end

function found_(message)
if error == 1 then
found2(message)
elseif error == 2 then
found3(message)
elseif error == 3 then
found4(message)
else
found(message)
end
end

function found(message)
if count == 0 then
gg.clearResults()
gg.clearList()
first_error = message
error = 1
second_start()
end
end

function found2(message)
if count == 0 then
gg.clearResults()
gg.clearList()
second_error = message
error = 2
third_start()
end
end

function found3(message)
if count == 0 then
gg.clearResults()
gg.clearList()
third_error = message
error = 3
fourth_start()
end
end

function found4(message)
if count == 0 then
gg.clearResults()
gg.clearList()
gg.setVisible(true)
gg.alert("❌Value NOT FOUND❌")
loopCheck()
end
end

function user_input_taker()
::stort::
gg.clearResults()
if userMode == 1 then
if Get_user_input == nil then
default1 = "PlayerController"
default2 = "0x148"
default3 = false
default4 = false
else
default1 = Get_user_input[1]
default2 = Get_user_input[2]
default3 = Get_user_input[3]
default4 = Get_user_input[4]
end
Get_user_input = gg.prompt(
{"Class Name: ", "Offset: ","Try Harder -- (decreases accuracy)","Try For 32 bit"},
{default1,default2,default3,default4},
{"text","text","checkbox","checkbox"})
if Get_user_input ~= nil then
if (Get_user_input[1] == "") or (Get_user_input[2] == "") then
gg.alert("ℹ️ Don't Leave Input Blankℹ️")
goto stort
end
else
gg.alert("ℹ️ Error : Try again ℹ️")
goto stort
end
Get_user_type = gg.choice({"1. Byte / Boolean","2. Dword / 32 bit Int","3. Qword / 64 bit Int","4. Float","5. Double"})
if Get_user_type == 1 then
Get_user_type = gg.TYPE_BYTE
elseif Get_user_type == 2 then
Get_user_type = gg.TYPE_DWORD
elseif Get_user_type == 3 then
Get_user_type = gg.TYPE_QWORD
elseif Get_user_type == 4 then
Get_user_type = gg.TYPE_FLOAT
elseif Get_user_type == 5 then
Get_user_type = gg.TYPE_DOUBLE
end
if Get_user_type ~= gg.TYPE_BYTE then
if (Get_user_input[2] % 4) ~= 0 then
gg.alert("ℹ️Hex Offset Must Be An Multiple OF 4ℹ️")
goto stort
end
end
end
error = 0 
end

function O_initial_search()
gg.setVisible(false)
gg.toast("🟢First Try")
user_input = ":"..Get_user_input[1] 
if Get_user_input[3] then
offst = 25
else
offst = 0
end
end

function O_dinitial_search()
if error > 1 then
gg.setRanges(gg.REGION_C_ALLOC)
else
gg.setRanges(gg.REGION_OTHER)
end
gg.searchNumber(user_input, gg.TYPE_BYTE)
count = gg.getResultsCount()
if count == 0 then
found_("O_dinitial_search")
return 0
end
Refiner = gg.getResults(1)
gg.refineNumber(Refiner[1].value, gg.TYPE_BYTE)
count = gg.getResultsCount()
if count == 0 then
found_("O_dinitial_search")
return 0
end
val = gg.getResults(count)
gg.addListItems(val)
end

function CA_pointer_search()
gg.clearResults()
gg.setRanges(gg.REGION_C_ALLOC | gg.REGION_OTHER)
gg.loadResults(gg.getListItems())
gg.searchPointer(offst)
count = gg.getResultsCount()
if count == 0 then
found_("CA_pointer_search")
return 0
end
vel = gg.getResults(count)
gg.clearList()
gg.addListItems(vel)
end

function CA_apply_offset()
if Get_user_input[4] then
tanker = 0xfffffffffffffff8
else
tanker = 0xfffffffffffffff0
end
local copy = false
local l = gg.getListItems()
if not copy then gg.removeListItems(l) end
for i, v in ipairs(l) do
	v.address = v.address + tanker
	if copy then v.name = v.name..' #2' end
end
gg.addListItems(l)
end

function CA2_apply_offset()
if Get_user_input[4] then
tanker = 0xfffffffffffffff8
else
tanker = 0xfffffffffffffff0
end
local copy = false
local l = gg.getListItems()
if not copy then gg.removeListItems(l) end
for i, v in ipairs(l) do
	v.address = v.address + tanker
	if copy then v.name = v.name..' #2' end
end
gg.addListItems(l)
end

function Q_apply_fix()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.loadResults(gg.getListItems())
gg.clearList()
count = gg.getResultsCount()
if count == 0 then
found_("Q_apply_fix")
return 0
end
yy = gg.getResults(1000)
gg.clearResults()
i = 1
c = 1
s = {}
while (i-1) < count do
yy[i].address = yy[i].address + 0xb400000000000000
gg.searchNumber(yy[i].address, gg.TYPE_QWORD)
cnt = gg.getResultsCount()
if 0 < cnt then
bytr = gg.getResults(cnt)
n = 1
while (n-1) < cnt do
s[c] = {}
s[c].address = bytr[n].address
s[c].flags = 32
n = n + 1
c = c + 1
end
end
gg.clearResults()
i = i + 1
end
gg.addListItems(s)
end

function A_base_value()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.loadResults(gg.getListItems())
gg.clearList()
gg.searchPointer(offst)
count = gg.getResultsCount()
if count == 0 then
found_("A_base_value")
return 0
end
tel = gg.getResults(count)
gg.addListItems(tel)
end

function A_base_accuracy()
gg.setRanges(gg.REGION_ANONYMOUS | gg.REGION_C_ALLOC)
gg.loadResults(gg.getListItems())
gg.clearList()
gg.searchPointer(offst)
count = gg.getResultsCount()
if count == 0 then
found_("A_base_accuracy")
return 0
end
kol = gg.getResults(count)
i = 1
h = {}
while (i-1) < count do
h[i] = {}
h[i].address = kol[i].value
h[i].flags = 32
i = i + 1
end
gg.addListItems(h)
end

function A_user_given_offset()
local old_save_list = gg.getListItems()
for i, v in ipairs(old_save_list) do
v.address = v.address + Get_user_input[2]
v.flags = Get_user_type
end
gg.clearResults()
gg.clearList()
gg.loadResults(old_save_list)
count = gg.getResultsCount()
if count == 0 then
found_("Q_apply_fix++")
return 0
end
end

function start()
user_input_taker()
O_initial_search()
O_dinitial_search()
if error > 0 then
return 0
end
CA_pointer_search()
if error > 0 then
return 0
end
CA_apply_offset()
if error > 0 then
return 0
end
A_base_value()
if error > 0 then
return 0
end
if offst == 0 then
A_base_accuracy()
end
if error > 0 then
return 0
end
A_user_given_offset()
if error > 0 then
return 0
end
loopCheck()
if error > 0 then
return 0
end
end

function second_start()
gg.toast("🟡Second Try")
O_dinitial_search()
if error > 1 then
return 0
end
CA_pointer_search()
if error > 1 then
return 0
end
CA_apply_offset()
if error > 1 then
return 0
end
Q_apply_fix()
if error > 1 then
return 0
end
if offst == 0 then
A_base_accuracy()
end
if error > 1 then
return 0
end
A_user_given_offset()
if error > 1 then
return 0
end
loopCheck()
if error > 1 then
return 0
end
end

function third_start()
gg.toast("🔴Third Try")
O_dinitial_search()
if error > 2 then
return 0
end
CA_pointer_search()
if error > 2 then
return 0
end
if offst == 0 then
CA2_apply_offset()
end
if error > 2 then
return 0
end
A_base_value()
if error > 2 then
return 0
end
if offst == 0 then
A_base_accuracy()
end
if error > 2 then
return 0
end
A_user_given_offset()
if error > 2 then
return 0
end
loopCheck()
if error > 2 then
return 0
end
end

function fourth_start()
gg.toast("☢️Fourth Try")
O_dinitial_search()
CA_pointer_search()
CA2_apply_offset()
Q_apply_fix()
if offst == 0 then
A_base_accuracy()
end
A_user_given_offset()
loopCheck()
end

function UI()
gg.showUiButton()
while true do
if gg.isClickedUiButton() then
start()
end
end
end

function TesterLua() end
function setvalue(address,flags,value) TesterLua('Modify address value(Address, value type, value to be modified)')
local tt = {}
tt[1]= {}
tt[1].address = address
tt[1].flags = flags
tt[1].value = value
gg.setValues(tt)
end

on = "🔴⃢  "
off = "    ⃢🟢"

-- coin
b2m = on
b500k = on
b50k = on
b40k = on
b30k = on
b20k = on
freezecoin = on

gg.setVisible(false)
gg.toast("CLICK GG LOGO")
function HOME()
QR = gg.choice({
[[ GET 2M COIN ]]..b2m, -- 1
[[ GET 500K COIN ]]..b500k, -- 2
[[ GET 50K COIN ]]..b50k, -- 3
[[ GET 40K COIN ]]..b40k, -- 4
[[ GET 30K COIN ]]..b30k, -- 5
[[ GET 20K COIN ]]..b20k, -- 6
[[ FREEZE COIN ]]..freezecoin, -- 7
[[ REDUCE COIN (WARDROBE) ]], -- 8
[[ REDUCE COIN (ANIMATIONS) ]], -- 9
[[ ❌ E X I T ❌ ]],
},nil,os.date[[
┏━━━━━━━✰✰✰━━━━━━━┓
👤Script by: CPM-GG-20
➣ ☀️Today: %m/%d/%y
➣ ⌚Time: %H:%M
┗━━━━━━━✰✰✰━━━━━━━┛
]])
if QR == nil then else
if QR == 1 then if b2m == on then  B1 (on) b2m = off else B2 (off) b2m = on end end
if QR == 2 then if b500k == on then  B3 (on) b500k = off else B4 (off) b500k = on end end
if QR == 3 then if b50k == on then  B5 (on) b50k = off else B6 (off) b50k = on end end
if QR == 4 then if b40k == on then  B7 (on) b40k = off else B8 (off) b40k = on end end
if QR == 5 then if b30k == on then  B9 (on) b30k = off else B10 (off) b30k = on end end
if QR == 6 then if b20k == on then  B11 (on) b20k = off else B12 (off) b20k = on end end
if QR == 7 then if freezecoin == on then  B13 (on) freezecoin = off else B14 (off) freezecoin = on end end
if QR == 8 then B15() end
if QR == 9 then B16() end
if QR == 10 then EXIT()
end
end
TESTER = -1
end

function B1() -- get 2m coin on
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x2A6CEA4 setvalue(Tester+Lua,16,-3.77822904e11)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x2A6CEA8 setvalue(Tester+Lua,16,-6.13017998e13)
gg.toast("GO TO LEVEL AND COME BACK")
end

function B2() -- get 2m coin off
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x2A6CEA4 setvalue(Tester+Lua,16,-1.28235374e34)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x2A6CEA8 setvalue(Tester+Lua,16,-2.87512967e-14)
gg.toast("OFF")
end

function B3() -- get 500k coin on
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x2A6CEA4 setvalue(Tester+Lua,16,-3.43605772e11)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x2A6CEA8 setvalue(Tester+Lua,16,-6.13017998e13)
gg.toast("GO TO LEVEL AND COME BACK")
end

function B4() -- get 500k coin off
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x2A6CEA4 setvalue(Tester+Lua,16,-1.28235374e34)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x2A6CEA8 setvalue(Tester+Lua,16,-2.87512967e-14)
gg.toast("OFF")
end

function B5() -- get 50k coin on
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x2A6CEA4 setvalue(Tester+Lua,16,-3.27306707e11)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x2A6CEA8 setvalue(Tester+Lua,16,-6.13017998e13)
gg.toast("GO TO LEVEL AND COME BACK")
end

function B6() -- get 50k coin off
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x2A6CEA4 setvalue(Tester+Lua,16,-1.28235374e34)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x2A6CEA8 setvalue(Tester+Lua,16,-2.87512967e-14)
gg.toast("OFF")
end

function B7() -- get 40k coin on
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x2A6CEA4 setvalue(Tester+Lua,16,-3.16820947e11)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x2A6CEA8 setvalue(Tester+Lua,16,-6.13017998e13)
gg.toast("GO TO LEVEL AND COME BACK")
end

function B8() -- get 40k coin off
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x2A6CEA4 setvalue(Tester+Lua,16,-1.28235374e34)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x2A6CEA8 setvalue(Tester+Lua,16,-2.87512967e-14)
gg.toast("OFF")
end

function B9() -- get 30k coin on
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x2A6CEA4 setvalue(Tester+Lua,16,-3.06335187e11)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x2A6CEA8 setvalue(Tester+Lua,16,-6.13017998e13)
gg.toast("GO TO LEVEL AND COME BACK")
end

function B10() -- get 30k coin on
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x2A6CEA4 setvalue(Tester+Lua,16,-1.28235374e34)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x2A6CEA8 setvalue(Tester+Lua,16,-2.87512967e-14)
gg.toast("OFF")
end

function B11() -- get 20k coin on
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x2A6CEA4 setvalue(Tester+Lua,16,-2.95849427e11)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x2A6CEA8 setvalue(Tester+Lua,16,-6.13017998e13)
gg.toast("GO TO LEVEL AND COME BACK")
end

function B12() -- get 20k coin off
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x2A6CEA4 setvalue(Tester+Lua,16,-1.28235374e34)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x2A6CEA8 setvalue(Tester+Lua,16,-2.87512967e-14)
gg.toast("OFF")
end

function B13() -- freeze coin on
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x2A6D8B0 setvalue(Tester+Lua,16,-2.74878956e11)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x2A6D8B4 setvalue(Tester+Lua,16,-6.13017998e13)
gg.toast("ON")
end

function B14() -- freeze coin off
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x2A6D8B0 setvalue(Tester+Lua,16,-8.45156464e-14)
Tester=gg.getRangesList('libil2cpp.so')[2].start
Lua=0x2A6D8B4 setvalue(Tester+Lua,16,-2.87512967e-14)
gg.toast("OFF")
end

function B15() -- reduce coin wardrobe
gg.setVisible(false)
gg.clearResults()
gg.clearList()
d=gg.prompt({"REDUCE COIN","BACK"},nil,{"number","checkbox"})
if not d then return end
if d == nil then Menu() end
if d[2] then return gg.setVisible(true) end
search("personKit","0x10", false, false, gg.TYPE_DWORD)
gg.getResults(9999)
gg.editAll(d[1], gg.TYPE_DWORD)
gg.alert("BUY ONE WARDROBE")
gg.toast("ON")
gg.clearResults()
gg.clearList()
end

function B16() -- reduce coin animations
gg.setVisible(false)
gg.clearResults()
gg.clearList()
d=gg.prompt({"REDUCE COIN","BACK"},nil,{"number","checkbox"})
if not d then return end
if d == nil then Menu() end
if d[2] then return gg.setVisible(true) end
search("AnimationInfo","0x20", false, false, gg.TYPE_DWORD)
gg.getResults(9999)
gg.editAll(d[1], gg.TYPE_DWORD)
gg.alert("BUY ONE ANIMATIONS")
gg.toast("ON")
gg.clearResults()
gg.clearList()
end

function EXIT()
gg.toast("EXIT ✔")
gg.clearResults()
gg.clearList()
os.exit()
end 

while true do
if gg.isVisible(true) then
TESTER = 1
gg.setVisible(false)
end
if TESTER == 1 then
HOME()
end
end
